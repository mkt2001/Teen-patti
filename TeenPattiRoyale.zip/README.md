# Teen Patti Royale - Offline Edition (Godot 4.2, Android)

Virtual coins only. No real money, no internet, no login.

## GitHub se APK banane ke steps
1. GitHub par naya repository banao (e.g. `TeenPattiRoyale`).
2. Is zip ko repo me upload karo (zip ko seedha upload kar sakte ho, ya extract karke saari files).
3. Agar zip seedha upload kiya hai: repo me `Add file > Create new file`, naam `.github/workflows/build.yml` likho aur `build.yml` ka content paste karo.
   (Extract karke upload kiya to ye file already `.github/workflows/` me hai.)
4. Repo `Settings > Actions > General > Workflow permissions` me **Read and write permissions** select karke Save karo.
5. `Actions` tab > `Build Android APK and publish Release` > `Run workflow`.
6. 5-10 minute baad `Releases` section me `TeenPattiRoyale.apk` milegi. Phone me download karke install karo (Unknown sources allow karna hoga).

## Features
14 game modes, 8 tables, 7 AI levels with personalities, betting (Boot/Blind/Seen/Chaal/Raise/Pack/Show/Side Show/Pot Limit),
tournaments vs AI, daily rewards, lucky spin, missions, achievements, shop (cards, backs, tables, avatars, VIP frames),
profile, statistics, leaderboard, history, settings (sound/music/vibration/quality/animation/language/theme/reset).
Save data: local, tamper-checked, auto-saved.
