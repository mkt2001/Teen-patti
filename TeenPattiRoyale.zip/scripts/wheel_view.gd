extends Control

const COLS = [Color("e53935"), Color("fb8c00"), Color("fdd835"), Color("43a047"), Color("1e88e5"), Color("8e24aa"), Color("d81b60"), Color("00acc1")]
var prizes = []
var is_pointer = false

func _notification(what):
    if what == NOTIFICATION_RESIZED:
        pivot_offset = size / 2.0

func _draw():
    if is_pointer:
        var m = size.x / 2.0
        draw_colored_polygon(PackedVector2Array([Vector2(m - 24, 0), Vector2(m + 24, 0), Vector2(m, 52)]), Color("ffffff"))
        draw_polyline(PackedVector2Array([Vector2(m - 24, 0), Vector2(m + 24, 0), Vector2(m, 52), Vector2(m - 24, 0)]), Color("b8860b"), 4.0)
        return
    var c = size / 2.0
    var r = minf(size.x, size.y) / 2.0 - 8.0
    var n = prizes.size()
    if n == 0:
        return
    draw_circle(c, r + 8, Color("f6c945"))
    var seg = 360.0 / n
    for i in range(n):
        var pts = PackedVector2Array([c])
        for k in range(0, 9):
            var a = deg_to_rad(i * seg + seg * k / 8.0)
            pts.append(c + Vector2(cos(a), sin(a)) * r)
        draw_colored_polygon(pts, COLS[i % COLS.size()])
    var font = ThemeDB.fallback_font
    for i in range(n):
        var am = deg_to_rad(i * seg + seg / 2.0)
        var p = c + Vector2(cos(am), sin(am)) * r * 0.66
        draw_set_transform(p, am, Vector2.ONE)
        draw_string(font, Vector2(-70, 12), _short(prizes[i]), HORIZONTAL_ALIGNMENT_CENTER, 140, 34, Color.WHITE)
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    draw_circle(c, r * 0.14, Color("f6c945"))
    draw_circle(c, r * 0.09, Color("6a2bd9"))

func _short(n):
    if n >= 10000000:
        return "%s Cr" % str(n / 10000000.0).rstrip("0").rstrip(".")
    if n >= 100000:
        return "%s L" % str(n / 100000.0).rstrip("0").rstrip(".")
    return str(n)
