extends Control

const Kit = preload("res://scripts/ui_kit.gd")
const HandEval = preload("res://scripts/hand_eval.gd")
const BotAI = preload("res://scripts/bot_ai.gd")
const TableBG = preload("res://scripts/table_bg.gd")
const AvatarView = preload("res://scripts/avatar_view.gd")
const CardView = preload("res://scripts/card_view.gd")
const WheelView = preload("res://scripts/wheel_view.gd")
const TableScript = preload("res://scripts/game_table.gd")

const PALETTE = [Color("6a2bd9"), Color("1565c0"), Color("00897b"), Color("ef6c00"), Color("c2185b"), Color("2e7d32"), Color("7b1fa2"), Color("d84315")]
const HOW_TEXT = "GOAL\nWin the pot by having the best 3-card hand, or by making everyone else pack.\n\nHAND RANKING (best to worst)\n1. Trail (three of a kind)\n2. Pure Sequence (straight flush)\n3. Sequence (straight)\n4. Color (flush)\n5. Pair\n6. High Card\nA-2-3 is the highest sequence, then A-K-Q.\n\nBETTING\nBoot: everyone puts the boot amount in the pot.\nBlind: you play without looking at cards. You pay the stake.\nSeen: after looking you pay double the stake.\nChaal: call the current stake.\nRaise: doubles the stake (up to the table maximum).\nPack: fold your hand.\nShow: only when 2 players remain - compare cards, the best hand wins. If equal, the player who asked loses.\nSide Show: a seen player may ask the previous seen player to compare. The weaker hand packs. If equal, the asker packs.\nPot Limit: when the pot reaches the table limit, everyone left shows.\n\nVIRTUAL COINS\nThis game uses virtual coins only. No real money, deposits, withdrawals or prizes.\n\nGAME MODES\nClassic, Muflis (lowest wins), AK47, Joker, 999, Lowest Joker, Best of Four, 2-3-5, 4-3-2, Pot Blind, AK47 Variation, Dealer's Choice, Heads Up and High-Low. Open Select Game Mode to read each rule."

var holder
var bgc
var toast_panel
var toast_lbl
var toast_tw = null
var table = null
var screen = "home"
var popup = null
var ai_cfg = {"mode": 0, "table": 0, "bots": 4, "diff": -1}
var shop_cat = "cd"
var tour_table = 0

func _ready():
    get_tree().set("quit_on_go_back", false)
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bgc = TableBG.new()
    bgc.menu_mode = true
    add_child(bgc)
    bgc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    holder = Control.new()
    add_child(holder)
    holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_toast()
    GameData.notify.connect(_toast)
    show_home()
    if not GameData.d["welcome"]:
        _welcome()

func _notification(what):
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _back()

func _back():
    if popup != null:
        _close_popup()
    elif table != null:
        table.back_pressed()
    elif screen != "home":
        show_home()
    else:
        _popup("EXIT GAME?", "Your progress is saved automatically.", [["EXIT", Color("c62828"), _quit], ["STAY", Color("2e7d32"), _close_popup]])

func _quit():
    GameData.save_game()
    get_tree().quit()

# ---------------------------------------------------------------- toast / popup
func _build_toast():
    toast_panel = PanelContainer.new()
    toast_panel.add_theme_stylebox_override("panel", Kit.sb(Color(0.1, 0.05, 0.25, 0.95), 22, Kit.GOLD, 3, 10))
    toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    toast_lbl = Kit.label("", 28, Color.WHITE)
    toast_panel.add_child(toast_lbl)
    add_child(toast_panel)
    toast_panel.visible = false

func _toast(msg):
    toast_lbl.text = str(msg)
    toast_panel.visible = true
    toast_panel.modulate = Color(1, 1, 1, 1)
    toast_panel.size = Vector2(0, 0)
    toast_panel.position = Vector2(size.x / 2.0 - 400, 18)
    toast_panel.custom_minimum_size = Vector2(800, 0)
    toast_panel.z_index = 100
    if toast_tw != null:
        toast_tw.kill()
    toast_tw = create_tween()
    toast_tw.tween_interval(2.4)
    toast_tw.tween_property(toast_panel, "modulate:a", 0.0, 0.5)
    toast_tw.tween_callback(_hide_toast)

func _hide_toast():
    toast_panel.visible = false

func _popup(title, text, buttons):
    _close_popup()
    var root = Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_STOP
    root.z_index = 50
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var cc = CenterContainer.new()
    root.add_child(cc)
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var pc = PanelContainer.new()
    pc.custom_minimum_size = Vector2(760, 0)
    var st = Kit.sb(Color(0.1, 0.05, 0.22, 0.98), 28, Kit.GOLD, 4, 18)
    st.set_content_margin_all(26)
    pc.add_theme_stylebox_override("panel", st)
    cc.add_child(pc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 14)
    pc.add_child(vb)
    vb.add_child(Kit.label(title, 42, Kit.GOLD))
    var l = Kit.label(text, 26)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size = Vector2(700, 0)
    vb.add_child(l)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 16)
    vb.add_child(hb)
    for b in buttons:
        var bt = Kit.button(b[0], b[1], 30, Vector2(0, 76))
        bt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        bt.pressed.connect(b[2])
        hb.add_child(bt)
    popup = root
    return vb

func _close_popup():
    if popup != null and is_instance_valid(popup):
        popup.queue_free()
    popup = null

func _welcome():
    _popup("WELCOME TO TEEN PATTI ROYALE", "You start with 10,00,00,000 virtual coins.\nClaim your free welcome bonus!\n(Virtual coins only - no real money.)", [["CLAIM +25,00,000", Color("2e7d32"), _claim_welcome]])

func _claim_welcome():
    var r = GameData.claim_welcome()
    _close_popup()
    Sfx.play("win")
    _toast("Welcome bonus +%s coins" % Kit.fmt(r))
    show_home()

# ---------------------------------------------------------------- helpers
func _clear():
    _close_popup()
    for c in holder.get_children():
        c.queue_free()

func _btn(parent, text, color, cb, size = Vector2(0, 80), fs = 28):
    var b = Kit.button(text, color, fs, size)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

func _new_screen(title, scr):
    screen = scr
    _clear()
    var root = VBoxContainer.new()
    holder.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 24
    root.offset_right = -24
    root.offset_top = 16
    root.offset_bottom = -16
    root.add_theme_constant_override("separation", 12)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 14)
    root.add_child(hb)
    _btn(hb, GameData.T("back"), Color("7b1fa2"), show_home, Vector2(170, 70), 26)
    var t = Kit.label(title, 40, Kit.GOLD)
    t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(t)
    hb.add_child(_coin_chip())
    var sc = ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(sc)
    var content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    sc.add_child(content)
    return content

func _coin_chip():
    var pc = PanelContainer.new()
    pc.add_theme_stylebox_override("panel", Kit.sb(Color(0, 0, 0, 0.45), 20, Kit.GOLD, 2))
    var l = Kit.label("COINS  " + Kit.fmt(GameData.d["coins"]), 28, Kit.GOLD)
    pc.add_child(l)
    return pc

func _selector(parent, title, opts, idx, cb):
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    parent.add_child(hb)
    var t = Kit.label(title, 28, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    t.custom_minimum_size = Vector2(260, 0)
    hb.add_child(t)
    var st = [idx]
    var val = Kit.label(str(opts[idx]), 28, Kit.GOLD)
    val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var lb = Kit.button("<", Color("6a2bd9"), 34, Vector2(90, 70))
    lb.pressed.connect(_sel_step.bind(st, -1, opts, val, cb))
    hb.add_child(lb)
    hb.add_child(val)
    var rb = Kit.button(">", Color("6a2bd9"), 34, Vector2(90, 70))
    rb.pressed.connect(_sel_step.bind(st, 1, opts, val, cb))
    hb.add_child(rb)

func _sel_step(st, delta, opts, lbl, cb):
    st[0] = (st[0] + delta + opts.size()) % opts.size()
    lbl.text = str(opts[st[0]])
    cb.call(st[0])

func _table_names():
    var out = []
    for t in GameData.TABLES:
        out.append(t["n"])
    return out

func _mode_names():
    var out = []
    for m in HandEval.MODES:
        out.append(m["name"])
    return out

func _mode_index(id):
    for i in range(HandEval.MODES.size()):
        if HandEval.MODES[i]["id"] == id:
            return i
    return 0

func _table_ok(idx, tour = false):
    var need = GameData.TABLES[idx]["boot"] * (20 if tour else 8)
    return GameData.d["coins"] >= need

# ---------------------------------------------------------------- home
func show_home():
    screen = "home"
    _clear()
    var root = VBoxContainer.new()
    holder.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 28
    root.offset_right = -28
    root.offset_top = 16
    root.offset_bottom = -16
    root.add_theme_constant_override("separation", 10)
    var hdr = HBoxContainer.new()
    hdr.add_theme_constant_override("separation", 16)
    root.add_child(hdr)
    var av = AvatarView.new()
    av.idx = GameData.d["avatar"]
    av.frame = GameData.d["frame"]
    av.custom_minimum_size = Vector2(100, 100)
    hdr.add_child(av)
    var info = VBoxContainer.new()
    info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hdr.add_child(info)
    info.add_child(Kit.label(GameData.d["name"], 32, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
    var need = GameData.xp_need(GameData.d["level"])
    info.add_child(Kit.label("Level %d     XP %d / %d" % [GameData.d["level"], GameData.d["xp"], need], 22, Color("c8f7ff"), HORIZONTAL_ALIGNMENT_LEFT))
    var xb = ProgressBar.new()
    xb.custom_minimum_size = Vector2(0, 14)
    xb.max_value = need
    xb.value = GameData.d["xp"]
    xb.show_percentage = false
    xb.add_theme_stylebox_override("background", Kit.sb(Color(1, 1, 1, 0.15), 7))
    xb.add_theme_stylebox_override("fill", Kit.sb(Kit.GOLD, 7))
    info.add_child(xb)
    hdr.add_child(_coin_chip())
    var ttl = Kit.label("TEEN PATTI ROYALE", 74, Kit.GOLD)
    root.add_child(ttl)
    var sub = Kit.label("OFFLINE EDITION   -   VIRTUAL COINS ONLY", 24, Color("c8f7ff"))
    root.add_child(sub)
    var tb = GameData.TABLES[GameData.d["last_table"]]
    var md = HandEval.mode_info(GameData.d["last_mode"])
    root.add_child(Kit.label("Mode: %s     Table: %s (Boot %s)" % [md["name"], tb["n"], Kit.short(tb["boot"])], 26, Color("ffe9a8")))
    var sc = ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(sc)
    var vb = VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.add_theme_constant_override("separation", 12)
    sc.add_child(vb)
    var top = HBoxContainer.new()
    top.add_theme_constant_override("separation", 14)
    vb.add_child(top)
    var pn = _btn(top, GameData.T("play_now"), Color("2e7d32"), _play_now, Vector2(0, 110), 42)
    pn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pn.size_flags_stretch_ratio = 2.0
    var qp = _btn(top, GameData.T("quick"), Color("ef6c00"), _quick_play, Vector2(0, 110), 32)
    qp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var ai = _btn(top, GameData.T("vs_ai"), Color("1565c0"), show_ai_setup, Vector2(0, 110), 32)
    ai.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var g = GridContainer.new()
    g.columns = 4
    g.add_theme_constant_override("h_separation", 12)
    g.add_theme_constant_override("v_separation", 12)
    vb.add_child(g)
    var items = [["mode", show_modes], ["table", show_tables], ["wallet", show_wallet], ["daily", show_daily], ["spin", show_spin],
        ["ach", show_ach], ["missions", show_missions], ["tour", show_tour], ["shop", show_shop], ["stats", show_stats],
        ["board", show_board], ["history", show_history], ["profile", show_profile], ["settings", show_settings], ["how", show_how]]
    var i = 0
    for it in items:
        var b = _btn(g, GameData.T(it[0]), PALETTE[i % PALETTE.size()], it[1], Vector2(0, 90), 24)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        i += 1

# ---------------------------------------------------------------- start games
func start_game(cfg):
    var idx = cfg["table"]
    var tour = cfg.get("tour", false)
    if not _table_ok(idx, tour):
        var need = GameData.TABLES[idx]["boot"] * (20 if tour else 8)
        _toast("You need at least %s coins for this table" % Kit.fmt(need))
        return
    GameData.d["last_table"] = idx
    GameData.d["last_mode"] = cfg["mode"]
    if tour:
        GameData.d["coins"] -= GameData.TABLES[idx]["boot"] * 20
        GameData.coins_changed.emit()
    GameData.save_game()
    _clear()
    table = TableScript.new()
    table.cfg = cfg
    table.exit_requested.connect(_on_table_exit)
    holder.add_child(table)
    screen = "table"

func _on_table_exit():
    if table != null:
        table.queue_free()
        table = null
    show_home()

func _play_now():
    start_game({"mode": GameData.d["last_mode"], "table": GameData.d["last_table"], "bots": GameData.d["bots_n"], "diff": GameData.d["diff"]})

func _quick_play():
    var t = GameData.d["last_table"]
    while t > 0 and not _table_ok(t):
        t -= 1
    start_game({"mode": "classic", "table": t, "bots": 4, "diff": -1})

# ---------------------------------------------------------------- AI setup
func show_ai_setup():
    var c = _new_screen(GameData.T("vs_ai"), "ai")
    ai_cfg["mode"] = _mode_index(GameData.d["last_mode"])
    ai_cfg["table"] = GameData.d["last_table"]
    ai_cfg["bots"] = GameData.d["bots_n"]
    ai_cfg["diff"] = GameData.d["diff"]
    var v = Kit.card(c)
    _selector(v, "Game Mode", _mode_names(), ai_cfg["mode"], func(i): ai_cfg["mode"] = i)
    _selector(v, "Table", _table_names(), ai_cfg["table"], func(i): ai_cfg["table"] = i)
    _selector(v, "AI Players", ["1", "2", "3", "4", "5"], ai_cfg["bots"] - 1, func(i): ai_cfg["bots"] = i + 1)
    var dn = ["Auto (by table)"]
    for n in BotAI.DIFF_NAMES:
        dn.append(n)
    _selector(v, "AI Level", dn, ai_cfg["diff"] + 1, func(i): ai_cfg["diff"] = i - 1)
    v.add_child(Kit.label("Heads Up always uses 1 AI player. Auto level gets harder on higher tables.", 22, Color("c8f7ff")))
    _btn(v, "START GAME", Color("2e7d32"), _start_ai, Vector2(0, 100), 40)

func _start_ai():
    GameData.d["bots_n"] = ai_cfg["bots"]
    GameData.d["diff"] = ai_cfg["diff"]
    start_game({"mode": HandEval.MODES[ai_cfg["mode"]]["id"], "table": ai_cfg["table"], "bots": ai_cfg["bots"], "diff": ai_cfg["diff"]})

# ---------------------------------------------------------------- modes / tables
func show_modes():
    var c = _new_screen(GameData.T("mode"), "modes")
    for m in HandEval.MODES:
        var v = Kit.card(c)
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 16)
        v.add_child(hb)
        var tv = VBoxContainer.new()
        tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(tv)
        tv.add_child(Kit.label(m["name"], 32, Kit.GOLD, HORIZONTAL_ALIGNMENT_LEFT))
        var d = Kit.label(m["desc"], 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        d.custom_minimum_size = Vector2(900, 0)
        tv.add_child(d)
        var sel = GameData.d["last_mode"] == m["id"]
        var b = Kit.button("SELECTED" if sel else "SELECT", Color("2e7d32") if sel else Color("6a2bd9"), 26, Vector2(230, 80))
        b.pressed.connect(_pick_mode.bind(m["id"]))
        hb.add_child(b)

func _pick_mode(id):
    GameData.d["last_mode"] = id
    GameData.dirty = true
    _toast("Mode selected: " + HandEval.mode_info(id)["name"])
    show_modes()

func show_tables():
    var c = _new_screen(GameData.T("table"), "tables")
    for i in range(GameData.TABLES.size()):
        var t = GameData.TABLES[i]
        var v = Kit.card(c)
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 16)
        v.add_child(hb)
        var tv = VBoxContainer.new()
        tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(tv)
        tv.add_child(Kit.label(t["n"], 34, PALETTE[i % PALETTE.size()].lightened(0.3), HORIZONTAL_ALIGNMENT_LEFT))
        tv.add_child(Kit.label("Boot %s   |   Min coins %s   |   Max stake %s   |   AI: %s - %s" % [Kit.short(t["boot"]), Kit.short(t["boot"] * 8), Kit.short(t["boot"] * 32), BotAI.DIFF_NAMES[t["dmin"]], BotAI.DIFF_NAMES[t["dmax"]]], 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        var ok = _table_ok(i)
        var sel = GameData.d["last_table"] == i
        var txt = "SELECTED" if sel else ("SELECT" if ok else "LOCKED")
        var b = Kit.button(txt, Color("2e7d32") if sel else Color("6a2bd9"), 26, Vector2(230, 80))
        b.disabled = not ok
        b.pressed.connect(_pick_table.bind(i))
        hb.add_child(b)

func _pick_table(i):
    GameData.d["last_table"] = i
    GameData.dirty = true
    _toast("Table selected: " + GameData.TABLES[i]["n"])
    show_tables()

# ---------------------------------------------------------------- wallet / rewards
func show_wallet():
    var c = _new_screen(GameData.T("wallet"), "wallet")
    var v = Kit.card(c)
    v.add_child(Kit.label("BALANCE", 28, Color("c8f7ff")))
    v.add_child(Kit.label(Kit.fmt(GameData.d["coins"]), 64, Kit.GOLD))
    v.add_child(Kit.label("%s virtual coins" % Kit.short(GameData.d["coins"]), 26, Color.WHITE))
    var v2 = Kit.card(c)
    v2.add_child(Kit.label("FREE COINS", 34, Kit.GOLD))
    if not GameData.d["welcome"]:
        _btn(v2, "CLAIM WELCOME BONUS +25,00,000", Color("2e7d32"), _wallet_welcome)
    if GameData.can_claim_daily():
        _btn(v2, "CLAIM DAILY REWARD", Color("ef6c00"), _wallet_daily)
    else:
        _btn(v2, "Daily reward claimed - come back tomorrow", Color("455a64"), show_wallet).disabled = true
    if GameData.spin_available():
        _btn(v2, "FREE LUCKY SPIN AVAILABLE", Color("c2185b"), show_spin)
    if GameData.low_bonus_ready():
        _btn(v2, "LOW BALANCE BONUS +20,00,000", Color("00897b"), _wallet_low)
    else:
        v2.add_child(Kit.label("Low balance bonus appears when you have under 1 L coins.", 22, Color("c8f7ff")))
    var v3 = Kit.card(c)
    v3.add_child(Kit.label("Coins are virtual and can never be bought with real money.", 24, Color("ffe9a8")))
    v3.add_child(Kit.label("Total won: %s     Total lost: %s" % [Kit.fmt(GameData.d["total_won"]), Kit.fmt(GameData.d["total_lost"])], 24))

func _wallet_welcome():
    _claim_welcome()
    show_wallet()

func _wallet_daily():
    var r = GameData.claim_daily()
    Sfx.play("win")
    _toast("Daily reward +%s coins" % Kit.fmt(r))
    show_wallet()

func _wallet_low():
    var r = GameData.claim_low_bonus()
    Sfx.play("coin")
    _toast("Bonus +%s coins" % Kit.fmt(r))
    show_wallet()

func show_daily():
    var c = _new_screen(GameData.T("daily"), "daily")
    var v = Kit.card(c)
    v.add_child(Kit.label("Login streak: %d day(s)" % GameData.d["login_streak"], 32, Kit.GOLD))
    var g = GridContainer.new()
    g.columns = 4
    g.add_theme_constant_override("h_separation", 12)
    g.add_theme_constant_override("v_separation", 12)
    v.add_child(g)
    var can = GameData.can_claim_daily()
    var cur = GameData.next_streak() if can else GameData.d["login_streak"]
    for i in range(7):
        var pc = PanelContainer.new()
        pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var col = Color(1, 1, 1, 0.1)
        var day_in_cycle = ((cur - 1) % 7) + 1
        if i + 1 < day_in_cycle or (i + 1 == day_in_cycle and not can):
            col = Color(0.18, 0.6, 0.3, 0.6)
        elif i + 1 == day_in_cycle:
            col = Color(0.96, 0.78, 0.27, 0.45)
        pc.add_theme_stylebox_override("panel", Kit.sb(col, 18, Color(1, 1, 1, 0.3), 2))
        var vb = VBoxContainer.new()
        pc.add_child(vb)
        vb.add_child(Kit.label("DAY %d" % (i + 1), 26, Color.WHITE))
        vb.add_child(Kit.label(Kit.short(GameData.DAILY_REWARDS[i]), 34, Kit.GOLD))
        g.add_child(pc)
    if can:
        _btn(v, "CLAIM TODAY'S REWARD", Color("2e7d32"), _daily_claim, Vector2(0, 100), 36)
    else:
        v.add_child(Kit.label("Already claimed today. Come back tomorrow!", 28, Color("c8f7ff")))

func _daily_claim():
    var r = GameData.claim_daily()
    Sfx.play("win")
    _toast("Daily reward +%s coins" % Kit.fmt(r))
    show_daily()

# ---------------------------------------------------------------- spin
var wheel = null
var spin_btn = null
var spinning = false

func show_spin():
    var c = _new_screen(GameData.T("spin"), "spin")
    var v = Kit.card(c)
    var wrap = Control.new()
    wrap.custom_minimum_size = Vector2(560, 600)
    wrap.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    v.add_child(wrap)
    wheel = WheelView.new()
    wheel.prizes = GameData.SPIN_PRIZES
    wheel.size = Vector2(520, 520)
    wheel.position = Vector2(20, 70)
    wheel.pivot_offset = Vector2(260, 260)
    wrap.add_child(wheel)
    var pt = WheelView.new()
    pt.is_pointer = true
    pt.size = Vector2(560, 60)
    pt.position = Vector2(0, 0)
    wrap.add_child(pt)
    var can = GameData.spin_available()
    spin_btn = _btn(v, "SPIN!" if can else "Come back tomorrow", Color("c2185b") if can else Color("455a64"), _do_spin, Vector2(0, 100), 40)
    spin_btn.disabled = not can
    spinning = false

func _do_spin():
    if spinning or not GameData.spin_available():
        return
    spinning = true
    spin_btn.disabled = true
    var idx = GameData.pick_spin()
    var seg = 360.0 / GameData.SPIN_PRIZES.size()
    var theta = idx * seg + seg / 2.0
    var cur = rad_to_deg(wheel.rotation)
    cur = fposmod(cur, 360.0)
    wheel.rotation = deg_to_rad(cur)
    var delta = fposmod(270.0 - theta + randf_range(-seg * 0.3, seg * 0.3) - cur, 360.0)
    var target = deg_to_rad(cur + 360.0 * 5.0 + delta)
    var tw = create_tween()
    tw.tween_property(wheel, "rotation", target, 4.5).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    for k in range(18):
        get_tree().create_timer(0.15 + k * 0.2 + k * k * 0.02).timeout.connect(_tick)
    tw.tween_callback(_spin_done.bind(idx))

func _tick():
    Sfx.play("tick")

func _spin_done(idx):
    GameData.finish_spin(idx)
    Sfx.play("win")
    Sfx.vibrate(150)
    _popup("YOU WON!", "+%s virtual coins" % Kit.fmt(GameData.SPIN_PRIZES[idx]), [["AWESOME", Color("2e7d32"), show_spin]])

# ---------------------------------------------------------------- missions / achievements
func show_missions():
    GameData.refresh_missions()
    var c = _new_screen(GameData.T("missions"), "missions")
    _mission_block(c, "DAILY MISSIONS", GameData.d["missions"]["daily"])
    _mission_block(c, "WEEKLY MISSIONS", GameData.d["missions"]["weekly"])

func _mission_block(c, title, lst):
    var v = Kit.card(c)
    v.add_child(Kit.label(title, 34, Kit.GOLD))
    for it in lst:
        var df = GameData.MISSION_DEFS[it["id"]]
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 14)
        v.add_child(hb)
        var tv = VBoxContainer.new()
        tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(tv)
        tv.add_child(Kit.label(df["t"] + "   (Reward " + Kit.short(df["r"]) + ")", 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        var pb = ProgressBar.new()
        pb.custom_minimum_size = Vector2(0, 18)
        pb.max_value = df["n"]
        pb.value = it["p"]
        pb.show_percentage = false
        pb.add_theme_stylebox_override("background", Kit.sb(Color(1, 1, 1, 0.15), 9))
        pb.add_theme_stylebox_override("fill", Kit.sb(Color("43a047"), 9))
        tv.add_child(pb)
        tv.add_child(Kit.label("%s / %s" % [Kit.short(it["p"]), Kit.short(df["n"])], 20, Color("c8f7ff"), HORIZONTAL_ALIGNMENT_LEFT))
        var done = it["p"] >= df["n"]
        var txt = "CLAIMED" if it["c"] else ("CLAIM" if done else "IN PROGRESS")
        var b = Kit.button(txt, Color("2e7d32") if (done and not it["c"]) else Color("455a64"), 24, Vector2(220, 80))
        b.disabled = it["c"] or not done
        b.pressed.connect(_claim_mission.bind(it))
        hb.add_child(b)

func _claim_mission(it):
    if GameData.claim_mission(it):
        Sfx.play("coin")
        _toast("Mission reward claimed!")
    show_missions()

func show_ach():
    GameData.check_achievements()
    var c = _new_screen(GameData.T("ach"), "ach")
    for a in GameData.ACHIEVEMENTS:
        var v = Kit.card(c, 14)
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 14)
        v.add_child(hb)
        var tv = VBoxContainer.new()
        tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(tv)
        tv.add_child(Kit.label(a["t"] + "   (Reward " + Kit.short(a["r"]) + ")", 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        var cur = mini(GameData.stat_value(a["stat"]), a["n"])
        var pb = ProgressBar.new()
        pb.custom_minimum_size = Vector2(0, 16)
        pb.max_value = a["n"]
        pb.value = cur
        pb.show_percentage = false
        pb.add_theme_stylebox_override("background", Kit.sb(Color(1, 1, 1, 0.15), 8))
        pb.add_theme_stylebox_override("fill", Kit.sb(Kit.GOLD, 8))
        tv.add_child(pb)
        var st = GameData.d["ach"].get(a["id"], 0)
        var txt = "LOCKED"
        var col = Color("455a64")
        if st == 1:
            txt = "CLAIM"
            col = Color("2e7d32")
        elif st == 2:
            txt = "DONE"
        var b = Kit.button(txt, col, 24, Vector2(200, 70))
        b.disabled = st != 1
        b.pressed.connect(_claim_ach.bind(a))
        hb.add_child(b)

func _claim_ach(a):
    if GameData.claim_ach(a):
        Sfx.play("win")
        _toast("Achievement reward +%s" % Kit.fmt(a["r"]))
    show_ach()

# ---------------------------------------------------------------- stats / history / board
func show_stats():
    var c = _new_screen(GameData.T("stats"), "stats")
    var d = GameData.d
    var played = maxi(1, d["played"])
    var v = Kit.card(c)
    var rows = [["Level", str(d["level"])], ["Total coins", Kit.fmt(d["coins"])], ["Games played", str(d["played"])], ["Games won", str(d["won"])], ["Games lost", str(d["lost"])],
        ["Winning percentage", "%.1f%%" % (100.0 * d["won"] / played)], ["Biggest win", Kit.fmt(d["biggest_win"])], ["Total winnings", Kit.fmt(d["total_won"])],
        ["Total losses", Kit.fmt(d["total_lost"])], ["Best win streak", str(d["best_streak"])], ["Trails won with", str(d["trails"])],
        ["Times packed", str(d["packs"])], ["Tournaments won", str(d["tour_wins"])], ["Login streak", str(d["login_streak"])]]
    for r in rows:
        var hb = HBoxContainer.new()
        v.add_child(hb)
        var a = Kit.label(r[0], 28, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(a)
        hb.add_child(Kit.label(r[1], 28, Kit.GOLD, HORIZONTAL_ALIGNMENT_RIGHT))

func show_history():
    var c = _new_screen(GameData.T("history"), "history")
    var v = Kit.card(c)
    if GameData.d["history"].is_empty():
        v.add_child(Kit.label("No hands played yet.", 28))
    for e in GameData.d["history"]:
        var net = e["net"]
        var col = Color("7CFC9A") if net >= 0 else Color("ff8a80")
        var t = "#%d  %s  (%s)  Pot %s  Winner: %s - %s   You: %s%s" % [e["n"], e["mode"], e["table"], Kit.short(e["pot"]), e["win"], e["hand"], "+" if net >= 0 else "", Kit.short(net)]
        var l = Kit.label(t, 22, col, HORIZONTAL_ALIGNMENT_LEFT)
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        l.custom_minimum_size = Vector2(1000, 0)
        v.add_child(l)

func show_board():
    var c = _new_screen(GameData.T("board"), "board")
    var v = Kit.card(c)
    v.add_child(Kit.label("Ranked by total offline winnings against AI bots", 24, Color("c8f7ff")))
    var rank = 1
    for e in GameData.leaderboard():
        var hb = HBoxContainer.new()
        v.add_child(hb)
        var col = Kit.GOLD if e["you"] else Color.WHITE
        var n = Kit.label("%d.  %s%s" % [rank, e["name"], "  (YOU)" if e["you"] else ""], 28, col, HORIZONTAL_ALIGNMENT_LEFT)
        n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(n)
        hb.add_child(Kit.label("%s   |   Won %d / %d" % [Kit.short(e["e"]), e["w"], e["p"]], 26, col, HORIZONTAL_ALIGNMENT_RIGHT))
        rank += 1

# ---------------------------------------------------------------- tournament
func show_tour():
    var c = _new_screen(GameData.T("tour"), "tour")
    var v = Kit.card(c)
    v.add_child(Kit.label("ROYAL AI TOURNAMENT", 38, Kit.GOLD))
    var t = Kit.label("5 hands against 5 AI bots, each player starts with 100x boot tournament chips (they are separate from your coins). Highest chips after 5 hands wins.\nEntry fee: 20x boot.   Prizes: 1st = 5x fee, 2nd = 3x fee, 3rd = 1.5x fee.", 24)
    t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    t.custom_minimum_size = Vector2(1000, 0)
    v.add_child(t)
    _selector(v, "Table", _table_names(), tour_table, func(i): tour_table = i)
    v.add_child(Kit.label("Tournaments won: %d" % GameData.d["tour_wins"], 26, Color("ffe9a8")))
    _btn(v, "ENTER TOURNAMENT", Color("c2185b"), _start_tour, Vector2(0, 100), 36)

func _start_tour():
    start_game({"mode": "classic", "table": tour_table, "bots": 5, "diff": -1, "tour": true})

# ---------------------------------------------------------------- shop / profile
func show_shop():
    var c = _new_screen(GameData.T("shop"), "shop")
    var tabs = HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 8)
    c.add_child(tabs)
    var cats = [["cd", "CARDS"], ["cb", "BACKS"], ["th", "TABLES"], ["av", "AVATARS"], ["fr", "FRAMES"]]
    for ct in cats:
        var b = Kit.button(ct[1], Color("2e7d32") if shop_cat == ct[0] else Color("6a2bd9"), 24, Vector2(0, 70))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_shop_cat.bind(ct[0]))
        tabs.add_child(b)
    var lst = GameData.cat_list(shop_cat)
    var key = GameData.cat_key(shop_cat)
    for i in range(lst.size()):
        var it = lst[i]
        var v = Kit.card(c, 14)
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 16)
        v.add_child(hb)
        hb.add_child(_preview(shop_cat, i))
        var tv = VBoxContainer.new()
        tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hb.add_child(tv)
        tv.add_child(Kit.label(it["n"], 30, Kit.GOLD, HORIZONTAL_ALIGNMENT_LEFT))
        var req = "Free" if it["p"] == 0 else ("Achievement reward" if it["p"] < 0 else "%s coins  -  Level %d" % [Kit.short(it["p"]), it["lv"]])
        tv.add_child(Kit.label(req, 22, Color("c8f7ff"), HORIZONTAL_ALIGNMENT_LEFT))
        var owned = GameData.owns(shop_cat, i)
        var eq = GameData.d[key] == i
        var txt = "BUY"
        var col = Color("ef6c00")
        if eq:
            txt = "EQUIPPED"
            col = Color("2e7d32")
        elif owned:
            txt = "EQUIP"
            col = Color("1565c0")
        elif it["p"] < 0:
            txt = "LOCKED"
            col = Color("455a64")
        var b = Kit.button(txt, col, 24, Vector2(210, 76))
        b.disabled = eq or (it["p"] < 0 and not owned)
        b.pressed.connect(_shop_buy.bind(i))
        hb.add_child(b)

func _preview(cat, i):
    if cat == "cd":
        var cv = CardView.new()
        cv.custom_minimum_size = Vector2(70, 100)
        cv.card = 12
        cv.face_up = true
        cv.design = i
        return cv
    if cat == "cb":
        var cb = CardView.new()
        cb.custom_minimum_size = Vector2(70, 100)
        cb.back_idx = i
        return cb
    if cat == "th":
        var th = TableBG.THEMES[i]
        var cr = ColorRect.new()
        cr.custom_minimum_size = Vector2(120, 80)
        cr.color = th["c1"]
        return cr
    var av = AvatarView.new()
    av.custom_minimum_size = Vector2(90, 90)
    if cat == "av":
        av.idx = i
        av.frame = 0
    else:
        av.idx = GameData.d["avatar"]
        av.frame = i
    return av

func _shop_cat(ct):
    shop_cat = ct
    show_shop()

func _shop_buy(i):
    var msg = GameData.buy(shop_cat, i)
    _toast(msg)
    show_shop()

var name_edit = null

func show_profile():
    var c = _new_screen(GameData.T("profile"), "profile")
    var v = Kit.card(c)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 16)
    v.add_child(hb)
    var av = AvatarView.new()
    av.idx = GameData.d["avatar"]
    av.frame = GameData.d["frame"]
    av.custom_minimum_size = Vector2(130, 130)
    hb.add_child(av)
    var tv = VBoxContainer.new()
    tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(tv)
    name_edit = LineEdit.new()
    name_edit.text = GameData.d["name"]
    name_edit.max_length = 14
    name_edit.custom_minimum_size = Vector2(0, 70)
    name_edit.add_theme_font_size_override("font_size", 30)
    tv.add_child(name_edit)
    _btn(tv, "SAVE NAME", Color("2e7d32"), _save_name, Vector2(0, 70), 26)
    v.add_child(Kit.label("Level %d     Coins %s     Won %d / %d" % [GameData.d["level"], Kit.short(GameData.d["coins"]), GameData.d["won"], GameData.d["played"]], 26, Color("ffe9a8")))
    var v2 = Kit.card(c)
    v2.add_child(Kit.label("AVATARS (tap to use)", 30, Kit.GOLD))
    var g = GridContainer.new()
    g.columns = 6
    g.add_theme_constant_override("h_separation", 12)
    g.add_theme_constant_override("v_separation", 12)
    v2.add_child(g)
    for i in range(GameData.AVATARS.size()):
        g.add_child(_pick_tile("av", i))
    var v3 = Kit.card(c)
    v3.add_child(Kit.label("VIP FRAMES (tap to use)", 30, Kit.GOLD))
    var g2 = GridContainer.new()
    g2.columns = 6
    g2.add_theme_constant_override("h_separation", 12)
    v3.add_child(g2)
    for i in range(GameData.FRAMES.size()):
        g2.add_child(_pick_tile("fr", i))
    _btn(c, "OPEN SHOP FOR MORE", Color("ef6c00"), show_shop, Vector2(0, 80))

func _pick_tile(cat, i):
    var b = Button.new()
    b.custom_minimum_size = Vector2(130, 130)
    b.focus_mode = Control.FOCUS_NONE
    var owned = GameData.owns(cat, i)
    var key = GameData.cat_key(cat)
    var sel = GameData.d[key] == i
    b.add_theme_stylebox_override("normal", Kit.sb(Color(0.18, 0.6, 0.3, 0.6) if sel else Color(1, 1, 1, 0.1), 18, Color(1, 1, 1, 0.3), 2))
    b.add_theme_stylebox_override("pressed", Kit.sb(Color(1, 1, 1, 0.3), 18))
    b.add_theme_stylebox_override("hover", Kit.sb(Color(1, 1, 1, 0.2), 18))
    var av = AvatarView.new()
    if cat == "av":
        av.idx = i
        av.frame = 0
    else:
        av.idx = GameData.d["avatar"]
        av.frame = i
    av.size = Vector2(100, 100)
    av.position = Vector2(15, 15)
    av.mouse_filter = Control.MOUSE_FILTER_IGNORE
    if not owned:
        av.modulate = Color(1, 1, 1, 0.3)
    b.add_child(av)
    b.pressed.connect(_pick_item.bind(cat, i))
    return b

func _pick_item(cat, i):
    if GameData.owns(cat, i):
        GameData.equip(cat, i)
        show_profile()
    else:
        _toast("Locked - get it in the Shop")

func _save_name():
    var n = name_edit.text.strip_edges()
    if n.length() < 2:
        _toast("Name must have at least 2 letters")
        return
    GameData.d["name"] = n
    GameData.save_game()
    _toast("Name saved")
    show_profile()

# ---------------------------------------------------------------- settings / how
func show_settings():
    var c = _new_screen(GameData.T("settings"), "settings")
    var s = GameData.d["settings"]
    var v = Kit.card(c)
    for k in [["sound", "Sound effects"], ["music", "Background music"], ["vib", "Vibration"], ["anim", "Animations"], ["dark", "Dark theme"]]:
        var b = Kit.button("%s:  %s" % [k[1], "ON" if s[k[0]] else "OFF"], Color("2e7d32") if s[k[0]] else Color("455a64"), 28, Vector2(0, 76))
        b.pressed.connect(_toggle.bind(k[0]))
        v.add_child(b)
    _selector(v, "Graphics quality", ["Low", "Medium", "High"], s["quality"], func(i): _set_val("quality", i))
    _selector(v, "Language", ["English", "Hinglish"], s["lang"], func(i): _set_val("lang", i))
    var v2 = Kit.card(c)
    _btn(v2, GameData.T("how"), Color("1565c0"), show_how, Vector2(0, 76))
    _btn(v2, "RESET GAME PROGRESS", Color("c62828"), _ask_reset, Vector2(0, 76))
    v2.add_child(Kit.label("Teen Patti Royale - Offline Edition v1.0\nVirtual entertainment only. No real money.", 22, Color("c8f7ff")))

func _toggle(key):
    GameData.d["settings"][key] = not GameData.d["settings"][key]
    GameData.dirty = true
    GameData.save_game()
    Sfx.apply_settings()
    bgc.queue_redraw()
    show_settings()

func _set_val(key, val):
    GameData.d["settings"][key] = val
    GameData.dirty = true
    GameData.save_game()

func _ask_reset():
    _popup("RESET PROGRESS?", "All coins, stats, items and achievements will be reset. Settings stay.", [["RESET", Color("c62828"), _do_reset], ["CANCEL", Color("455a64"), _close_popup]])

func _do_reset():
    GameData.reset_progress()
    _close_popup()
    _toast("Progress reset. 10 Crore coins restored.")
    show_home()

func show_how():
    var c = _new_screen(GameData.T("how"), "how")
    var v = Kit.card(c)
    var l = Kit.label(HOW_TEXT, 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size = Vector2(1000, 0)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v.add_child(l)
