extends Control

const DESIGNS = [
    {"bg": Color("ffffff"), "border": Color("c9c9c9"), "black": Color("1a1a1a"), "red": Color("d6212f")},
    {"bg": Color("fff4d6"), "border": Color("d4a017"), "black": Color("2b2108"), "red": Color("b3261e")},
    {"bg": Color("e8f0ff"), "border": Color("3f6fd1"), "black": Color("12245a"), "red": Color("c2185b")},
    {"bg": Color("1f1f2e"), "border": Color("8e7cff"), "black": Color("e8e8ff"), "red": Color("ff5c7a")},
    {"bg": Color("ffe8ee"), "border": Color("e57399"), "black": Color("4a1230"), "red": Color("d81b60")},
    {"bg": Color("e6fff0"), "border": Color("2e9e5f"), "black": Color("0b3d24"), "red": Color("c62828")}
]
const BACKS = [
    {"c1": Color("b71c1c"), "c2": Color("ffcdd2")}, {"c1": Color("0d47a1"), "c2": Color("bbdefb")},
    {"c1": Color("1b5e20"), "c2": Color("c8e6c9")}, {"c1": Color("4a148c"), "c2": Color("e1bee7")},
    {"c1": Color("111111"), "c2": Color("f6c945")}, {"c1": Color("006064"), "c2": Color("b2ebf2")}
]

var card = -1
var face_up = false
var wild = false
var glow = false
var design = 0
var back_idx = 0
var _flipping = false

func _notification(what):
    if what == NOTIFICATION_RESIZED:
        pivot_offset = size / 2.0

func _rank_text(r):
    if r <= 10:
        return str(r)
    return ["J", "Q", "K", "A"][r - 11]

func _draw():
    var rad = int(maxf(6.0, size.x * 0.09))
    var s = StyleBoxFlat.new()
    s.set_corner_radius_all(rad)
    if face_up and card >= 0:
        var dz = DESIGNS[design % DESIGNS.size()]
        s.bg_color = dz["bg"]
        s.border_color = Color("f6c945") if glow else dz["border"]
        s.set_border_width_all(5 if glow else 2)
        if GameData.d["settings"]["quality"] > 0:
            s.shadow_size = 5
            s.shadow_color = Color(0, 0, 0, 0.4)
        draw_style_box(s, Rect2(Vector2.ZERO, size))
        var rank = card % 13 + 2
        var suit = card / 13
        var col = dz["black"]
        if suit == 1 or suit == 2:
            col = dz["red"]
        var font = ThemeDB.fallback_font
        var fs = int(size.x * 0.28)
        draw_string(font, Vector2(size.x * 0.08, fs + size.y * 0.03), _rank_text(rank), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
        _suit(Vector2(size.x * 0.19, fs + size.y * 0.1 + size.x * 0.1), size.x * 0.16, suit, col)
        _suit(Vector2(size.x * 0.5, size.y * 0.58), size.x * 0.3, suit, col)
        draw_set_transform(size, PI, Vector2.ONE)
        draw_string(font, Vector2(size.x * 0.08, fs + size.y * 0.03), _rank_text(rank), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
        _suit(Vector2(size.x * 0.19, fs + size.y * 0.1 + size.x * 0.1), size.x * 0.16, suit, col)
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
        if wild:
            var bw = size.x * 0.5
            draw_rect(Rect2(size.x - bw - 4, size.y - size.y * 0.2, bw, size.y * 0.16), Color(0.96, 0.78, 0.27, 0.95))
            draw_string(font, Vector2(size.x - bw + 2, size.y - size.y * 0.075), "JOKER", HORIZONTAL_ALIGNMENT_LEFT, -1, int(size.x * 0.15), Color("3b1d00"))
    else:
        var bk = BACKS[back_idx % BACKS.size()]
        s.bg_color = bk["c1"]
        s.border_color = Color.WHITE
        s.set_border_width_all(3)
        if GameData.d["settings"]["quality"] > 0:
            s.shadow_size = 4
            s.shadow_color = Color(0, 0, 0, 0.4)
        draw_style_box(s, Rect2(Vector2.ZERO, size))
        var inset = size.x * 0.1
        var inner = StyleBoxFlat.new()
        inner.bg_color = Color(0, 0, 0, 0)
        inner.border_color = bk["c2"]
        inner.set_border_width_all(2)
        inner.set_corner_radius_all(maxi(3, rad - 3))
        draw_style_box(inner, Rect2(Vector2(inset, inset), size - Vector2(inset * 2, inset * 2)))
        var c2 = Color(bk["c2"].r, bk["c2"].g, bk["c2"].b, 0.45)
        var step = size.x * 0.17
        var y = inset + step * 0.5
        var row = 0
        while y < size.y - inset:
            var x = inset + step * 0.5 + (step * 0.5 if row % 2 == 1 else 0.0)
            while x < size.x - inset:
                draw_circle(Vector2(x, y), size.x * 0.025, c2)
                x += step
            y += step * 0.8
            row += 1
        draw_circle(size / 2.0, size.x * 0.24, bk["c1"])
        draw_arc(size / 2.0, size.x * 0.24, 0.0, TAU, 32, bk["c2"], 3.0)
        _diamond(size / 2.0, size.x * 0.14, bk["c2"])

func _diamond(c, s, col):
    draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s), c + Vector2(s * 0.7, 0), c + Vector2(0, s), c + Vector2(-s * 0.7, 0)]), col)

func _heart(c, s, col, flip):
    var f = 1.0 if flip == 1 else -1.0
    draw_circle(c + Vector2(-0.25 * s, -0.2 * s * f), 0.3 * s, col)
    draw_circle(c + Vector2(0.25 * s, -0.2 * s * f), 0.3 * s, col)
    draw_colored_polygon(PackedVector2Array([c + Vector2(-0.52 * s, -0.12 * s * f), c + Vector2(0.52 * s, -0.12 * s * f), c + Vector2(0, 0.6 * s * f)]), col)

func _suit(c, s, suit, col):
    if suit == 1:
        _heart(c, s, col, 1)
    elif suit == 0:
        _heart(c, s, col, -1)
        draw_colored_polygon(PackedVector2Array([c + Vector2(-0.1 * s, 0.3 * s), c + Vector2(0.1 * s, 0.3 * s), c + Vector2(0.22 * s, 0.7 * s), c + Vector2(-0.22 * s, 0.7 * s)]), col)
    elif suit == 2:
        draw_colored_polygon(PackedVector2Array([c + Vector2(0, -0.65 * s), c + Vector2(0.45 * s, 0), c + Vector2(0, 0.65 * s), c + Vector2(-0.45 * s, 0)]), col)
    else:
        draw_circle(c + Vector2(0, -0.3 * s), 0.26 * s, col)
        draw_circle(c + Vector2(-0.3 * s, 0.1 * s), 0.26 * s, col)
        draw_circle(c + Vector2(0.3 * s, 0.1 * s), 0.26 * s, col)
        draw_circle(c, 0.15 * s, col)
        draw_colored_polygon(PackedVector2Array([c + Vector2(-0.1 * s, 0.1 * s), c + Vector2(0.1 * s, 0.1 * s), c + Vector2(0.22 * s, 0.66 * s), c + Vector2(-0.22 * s, 0.66 * s)]), col)

func flip_to(up, dur = 0.22):
    if up == face_up or _flipping:
        return
    if not GameData.d["settings"]["anim"]:
        face_up = up
        queue_redraw()
        return
    _flipping = true
    var t = create_tween()
    t.tween_property(self, "scale:x", 0.0, dur)
    await t.finished
    face_up = up
    queue_redraw()
    var t2 = create_tween()
    t2.tween_property(self, "scale:x", 1.0, dur)
    await t2.finished
    _flipping = false
