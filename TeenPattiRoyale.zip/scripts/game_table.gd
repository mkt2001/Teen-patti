extends Control

const HandEval = preload("res://scripts/hand_eval.gd")
const BotAI = preload("res://scripts/bot_ai.gd")
const CardView = preload("res://scripts/card_view.gd")
const AvatarView = preload("res://scripts/avatar_view.gd")
const EmojiView = preload("res://scripts/emoji_view.gd")
const ChipView = preload("res://scripts/chip_view.gd")
const TableBG = preload("res://scripts/table_bg.gd")
const Kit = preload("res://scripts/ui_kit.gd")

signal exit_requested
signal action_chosen(act)
signal modal_answer(ans)
signal result_closed(cont)

const OPP_POS = {
    1: [Vector2(0.5, 0.11)],
    2: [Vector2(0.22, 0.2), Vector2(0.78, 0.2)],
    3: [Vector2(0.1, 0.42), Vector2(0.5, 0.11), Vector2(0.9, 0.42)],
    4: [Vector2(0.1, 0.47), Vector2(0.3, 0.12), Vector2(0.7, 0.12), Vector2(0.9, 0.47)],
    5: [Vector2(0.08, 0.47), Vector2(0.22, 0.12), Vector2(0.5, 0.12), Vector2(0.78, 0.12), Vector2(0.92, 0.47)]
}
const DEALER_POOL = ["classic", "muflis", "ak47", "joker", "n999", "lowjoker", "bestof4", "n235", "n432", "potblind", "ak47v", "highlow"]

var cfg = {}
var tb = {}
var boot = 0
var max_stake = 0
var pot_limit = 0
var players = []
var human = null
var seats = []
var pot = 0
var stake = 0
var round_no = 1
var dealer = -1
var hand_no = 0
var rm = "classic"
var cur_mode = "classic"
var joker_rank = 0
var alive = true
var ending = false
var forced_show = false
var show_requester = null
var timer_left = 0.0
var timer_total = 25.0
var timer_on = false
var modal_token = 0
var tour = false
var tour_left = 0
var tour_fee = 0
var session_hist = []
var deck = []
var fast = false
var in_hand = false
var overlay = null
var overlay_kind = ""
var say_tw = null

var bg
var lbl_title
var lbl_rule
var lbl_pot
var lbl_stake
var pot_chip
var lbl_hand
var lbl_say
var btns = {}
var bar
var tbar
var all_cards = []

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    tb = GameData.TABLES[int(cfg.get("table", 0))]
    boot = tb["boot"]
    max_stake = boot * 32
    pot_limit = boot * 1500
    tour = cfg.get("tour", false)
    if tour:
        tour_left = 5
        tour_fee = boot * 20
    _build_ui()
    _setup_players()
    resized.connect(_layout)
    _layout()
    _session()

func _sc():
    if GameData.d["settings"]["anim"]:
        return 1.0
    return 0.25

func _wait(t):
    var tt = t * (0.33 if fast else 1.0)
    if not GameData.d["settings"]["anim"]:
        tt *= 0.4
    await get_tree().create_timer(tt).timeout

# ------------------------------------------------------------------ UI build
func _build_ui():
    bg = TableBG.new()
    bg.theme_idx = GameData.d["theme"]
    add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var top = HBoxContainer.new()
    top.add_theme_constant_override("separation", 10)
    add_child(top)
    top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    top.offset_left = 14
    top.offset_right = -14
    top.offset_top = 10
    top.offset_bottom = 78
    var b1 = Kit.button("MENU", Color("7b1fa2"), 24, Vector2(140, 64))
    b1.pressed.connect(_open_menu)
    top.add_child(b1)
    lbl_title = Kit.label("", 28, Kit.GOLD)
    lbl_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(lbl_title)
    var b2 = Kit.button("HISTORY", Color("37474f"), 22, Vector2(150, 64))
    b2.pressed.connect(_open_history)
    top.add_child(b2)
    var b3 = Kit.button("EMOJI", Color("ef6c00"), 22, Vector2(130, 64))
    b3.pressed.connect(_open_emoji)
    top.add_child(b3)

    pot_chip = ChipView.new()
    pot_chip.size = Vector2(70, 70)
    add_child(pot_chip)
    lbl_pot = Kit.label("POT 0", 42, Kit.GOLD)
    add_child(lbl_pot)
    lbl_stake = Kit.label("", 24, Color("ffe9a8"))
    add_child(lbl_stake)
    lbl_rule = Kit.label("", 22, Color("c8f7ff"))
    add_child(lbl_rule)
    lbl_hand = Kit.label("", 30, Color.WHITE)
    add_child(lbl_hand)
    lbl_say = Kit.label("", 36, Color.WHITE)
    lbl_say.modulate = Color(1, 1, 1, 0)
    add_child(lbl_say)

    bar = PanelContainer.new()
    bar.add_theme_stylebox_override("panel", Kit.sb(Color(0.05, 0.02, 0.15, 0.9), 0, Kit.GOLD, 2))
    add_child(bar)
    bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    bar.offset_top = -140
    var vb = VBoxContainer.new()
    vb.size_flags_vertical = Control.SIZE_EXPAND_FILL
    bar.add_child(vb)
    tbar = ProgressBar.new()
    tbar.custom_minimum_size = Vector2(0, 14)
    tbar.max_value = 1.0
    tbar.value = 0.0
    tbar.show_percentage = false
    tbar.add_theme_stylebox_override("background", Kit.sb(Color(1, 1, 1, 0.12), 7))
    tbar.add_theme_stylebox_override("fill", Kit.sb(Kit.GOLD, 7))
    vb.add_child(tbar)
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
    vb.add_child(hb)
    var specs = [["pack", "PACK", Color("c62828")], ["see", "SEE CARDS", Color("1565c0")], ["side", "SIDE SHOW", Color("6a1b9a")], ["show", "SHOW", Color("ef6c00")], ["chaal", "CHAAL", Color("2e7d32")], ["raise", "RAISE", Color("00897b")]]
    for sp in specs:
        var b = Kit.button(sp[1], sp[2], 24, Vector2(0, 76))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_on_btn.bind(sp[0]))
        hb.add_child(b)
        btns[sp[0]] = b
    _set_buttons(false)

func _on_btn(act):
    action_chosen.emit(act)

func _set_buttons(on):
    for k in btns.keys():
        btns[k].disabled = not on

func _new_player(nm, is_human, av, fr, chips):
    return {"idx": players.size(), "name": nm, "human": is_human, "avatar": av, "frame": fr, "chips": chips,
        "cards": [], "views": [], "seen": false, "packed": false, "in": true, "bet": 0, "pers": "Balanced", "diff": 2, "ev": null}

func _setup_players():
    var nb = clampi(int(cfg.get("bots", 4)), 1, 5)
    if cfg.get("mode", "classic") == "headsup":
        nb = 1
    var start_chips = GameData.d["coins"]
    if tour:
        start_chips = boot * 100
    human = _new_player(GameData.d["name"], true, GameData.d["avatar"], GameData.d["frame"], start_chips)
    players.append(human)
    var picks = BotAI.pick(nb)
    for i in range(nb):
        var r = picks[i]
        var df = int(cfg.get("diff", -1))
        if df < 0:
            df = randi_range(tb["dmin"], tb["dmax"])
        var bp = _new_player(r["n"], false, r["a"], randi() % 7, boot * randi_range(80, 400))
        if tour:
            bp["chips"] = boot * 100
        bp["pers"] = r["p"]
        bp["diff"] = df
        players.append(bp)
    for p in players:
        seats.append(_make_seat(p))

func _make_seat(p):
    var s = {}
    var root = Panel.new()
    if p["human"]:
        root.size = Vector2(300, 108)
    else:
        root.size = Vector2(250, 205)
    root.add_theme_stylebox_override("panel", Kit.sb(Color(0.08, 0.03, 0.2, 0.75), 22, Color(1, 1, 1, 0.25), 3))
    add_child(root)
    var av = AvatarView.new()
    av.idx = p["avatar"]
    av.frame = p["frame"]
    av.size = Vector2(92, 92)
    av.position = Vector2(8, 8)
    root.add_child(av)
    var nm = Kit.label(p["name"], 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    nm.position = Vector2(106, 6)
    nm.size = Vector2(140, 30)
    nm.clip_text = true
    root.add_child(nm)
    var ch = Kit.label("", 24, Kit.GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    ch.position = Vector2(106, 38)
    ch.size = Vector2(140, 28)
    root.add_child(ch)
    var st = Kit.label("", 20, Color("9be7ff"), HORIZONTAL_ALIGNMENT_LEFT)
    st.position = Vector2(106, 68)
    st.size = Vector2(190, 26)
    root.add_child(st)
    var badge = Kit.label("D", 22, Color.BLACK)
    badge.add_theme_stylebox_override("normal", Kit.sb(Kit.GOLD, 17))
    badge.size = Vector2(34, 34)
    badge.position = Vector2(root.size.x - 28, -12)
    badge.visible = false
    root.add_child(badge)
    s["root"] = root
    s["chips"] = ch
    s["status"] = st
    s["badge"] = badge
    _update_seat_from(s, p)
    return s

func _update_seat_from(s, p):
    s["chips"].text = Kit.short(p["chips"])
    var t = ""
    if not p["in"]:
        t = "SITTING OUT"
    elif p["packed"]:
        t = "PACKED"
    else:
        t = ("SEEN" if p["seen"] else "BLIND") + "  " + Kit.short(p["bet"])
    s["status"].text = t
    if p["packed"] or not p["in"]:
        s["root"].modulate = Color(1, 1, 1, 0.55)
    else:
        s["root"].modulate = Color(1, 1, 1, 1)

func _update_seat(p):
    _update_seat_from(seats[p["idx"]], p)

func _set_turn(p):
    for i in range(seats.size()):
        var col = Color(1, 1, 1, 0.25)
        var w = 3
        if p != null and i == p["idx"]:
            col = Kit.GOLD
            w = 6
        seats[i]["root"].add_theme_stylebox_override("panel", Kit.sb(Color(0.08, 0.03, 0.2, 0.75), 22, col, w))

# ------------------------------------------------------------------ layout
func _pot_pos():
    return Vector2(size.x / 2.0, size.y * 0.44)

func _card_target(pi, i, n):
    if pi == 0:
        var total = 130 + (n - 1) * 100
        return Vector2(size.x / 2.0 - total / 2.0 + i * 100, size.y - 140 - 204)
    return seats[pi]["root"].position + Vector2(10 + i * 44, 102)

func _layout():
    if seats.is_empty():
        return
    var sz = size
    var nb = players.size() - 1
    var pl = OPP_POS[nb]
    for i in range(1, players.size()):
        var rt = seats[i]["root"]
        var fp = pl[i - 1]
        var x = clampf(sz.x * fp.x, rt.size.x / 2.0 + 8, sz.x - rt.size.x / 2.0 - 8)
        rt.position = Vector2(x - rt.size.x / 2.0, sz.y * fp.y)
    var hr = seats[0]["root"]
    hr.position = Vector2(16, sz.y - 140 - hr.size.y - 12)
    var pc = _pot_pos()
    pot_chip.position = pc - Vector2(35, 78)
    lbl_pot.size = Vector2(500, 50)
    lbl_pot.position = Vector2(pc.x - 250, pc.y - 8)
    lbl_stake.size = Vector2(900, 34)
    lbl_stake.position = Vector2(pc.x - 450, pc.y + 44)
    lbl_rule.size = Vector2(1500, 30)
    lbl_rule.position = Vector2(sz.x / 2.0 - 750, 82)
    lbl_say.size = Vector2(1200, 50)
    lbl_say.position = Vector2(pc.x - 600, pc.y + 86)
    lbl_hand.size = Vector2(700, 40)
    lbl_hand.position = Vector2(sz.x / 2.0 - 350, sz.y - 140 - 204 - 46)
    for p in players:
        for i in range(p["views"].size()):
            p["views"][i].position = _card_target(p["idx"], i, p["views"].size())

# ------------------------------------------------------------------ helpers
func _say(t, dur = 1.6):
    lbl_say.text = t
    lbl_say.modulate = Color(1, 1, 1, 1)
    if say_tw != null:
        say_tw.kill()
    say_tw = create_tween()
    say_tw.tween_interval(dur)
    say_tw.tween_property(lbl_say, "modulate:a", 0.0, 0.4)

func _update_pot():
    lbl_pot.text = "POT  " + Kit.fmt(pot)
    pot_chip.count = clampi(int(pot / (boot * 4)) + 1, 1, 8)
    pot_chip.queue_redraw()
    lbl_stake.text = "Stake %s   |   Max %s   |   Boot %s   |   Round %d" % [Kit.short(stake), Kit.short(max_stake), Kit.short(boot), round_no]

func _chip_fly(from_pos, to_pos, count = 1):
    for i in range(count):
        var c = ChipView.new()
        c.size = Vector2(38, 38)
        var cols = [Color("d62839"), Color("1d6fd1"), Color("f6c945"), Color("2e9e4f")]
        c.col = cols[randi() % 4]
        c.position = from_pos - c.size / 2.0 + Vector2(randf_range(-8, 8), randf_range(-8, 8))
        add_child(c)
        var tw = create_tween()
        tw.tween_property(c, "position", to_pos - c.size / 2.0, 0.45 * _sc()).set_delay(i * 0.06).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        tw.tween_callback(c.queue_free)

func _seat_center(p):
    var rt = seats[p["idx"]]["root"]
    return rt.position + rt.size / 2.0

func _eval(p):
    return HandEval.evaluate(p["cards"], rm, {"joker": joker_rank})

func _active_list():
    var out = []
    for p in players:
        if p["in"] and not p["packed"]:
            out.append(p)
    return out

func _active_count():
    return _active_list().size()

func _next_in(i):
    var n = players.size()
    for k in range(1, n + 1):
        var j = (i + k) % n
        if players[j]["in"]:
            return j
    return i

func _next_active(i):
    var n = players.size()
    for k in range(1, n + 1):
        var j = (i + k) % n
        if players[j]["in"] and not players[j]["packed"]:
            return j
    return i

func _prev_active(p):
    var n = players.size()
    for k in range(1, n):
        var j = (p["idx"] - k + n * 2) % n
        if players[j]["in"] and not players[j]["packed"]:
            return players[j]
    return null

func _chaal_cost(p):
    return stake * (2 if p["seen"] else 1)

func _raise_stake():
    if stake * 2 <= max_stake:
        return stake * 2
    return -1

func _raise_cost(p):
    var ns = _raise_stake()
    if ns < 0:
        return -1
    return ns * (2 if p["seen"] else 1)

func _can_see(p):
    if p["seen"]:
        return false
    if rm == "potblind" and round_no < 3:
        return false
    return true

func _can_side(p):
    if not p["seen"] or _active_count() <= 2 or rm == "headsup":
        return false
    var prev = _prev_active(p)
    if prev == null or not prev["seen"]:
        return false
    return p["chips"] >= _chaal_cost(p)

func _ctx(p):
    var s = HandEval.strength(_eval(p))
    if rm == "muflis":
        s = 1.0 - s
    return {"round": round_no, "active": _active_count(), "chaal": _chaal_cost(p), "raise": _raise_cost(p),
        "can_see": _can_see(p), "can_show": _active_count() == 2, "can_side": _can_side(p), "strength": s}

func _rule_text():
    var t = HandEval.mode_info(cur_mode)["desc"]
    if rm == "joker":
        t += "  JOKER RANK: " + HandEval.rank_word(joker_rank)
    return t

func _clear_cards():
    for v in all_cards:
        if is_instance_valid(v):
            v.queue_free()
    all_cards.clear()
    for p in players:
        p["views"] = []
    lbl_hand.text = ""

# ------------------------------------------------------------------ actions
func _pay(p, amt):
    p["chips"] -= amt
    p["bet"] += amt
    pot += amt
    if p["human"] and not tour:
        GameData.set_coins(p["chips"])
    _update_seat(p)
    _update_pot()
    _chip_fly(_seat_center(p), _pot_pos())
    Sfx.play("chip")

func _do_see(p):
    p["seen"] = true
    Sfx.play("flip")
    if p["human"]:
        for v in p["views"]:
            v.flip_to(true)
        _mark_wild(p)
        _update_hand_label()
    _update_seat(p)

func _mark_wild(p):
    var flags = HandEval.wild_flags(p["cards"], rm, {"joker": joker_rank})
    for i in range(p["views"].size()):
        if i < flags.size():
            p["views"][i].wild = flags[i]
            p["views"][i].queue_redraw()

func _update_hand_label():
    if human["seen"] and human["in"] and not human["packed"] and human["cards"].size() > 0:
        lbl_hand.text = "Your hand: " + HandEval.describe(_eval(human))
    else:
        lbl_hand.text = ""

func _do_pack(p):
    p["packed"] = true
    for v in p["views"]:
        v.modulate = Color(1, 1, 1, 0.4)
    Sfx.play("pack")
    _say("%s packed" % p["name"], 1.2)
    _update_seat(p)
    if p["human"]:
        fast = true
        lbl_hand.text = ""
        GameData.d["packs"] += 1
        GameData.mission_event("pack")
    elif randf() < 0.25:
        _emoji_pop(p["idx"], [2, 3, 6][randi() % 3])

func _do_chaal(p, is_raise):
    var cost = _raise_cost(p) if is_raise else _chaal_cost(p)
    if is_raise:
        stake = _raise_stake()
    _pay(p, cost)
    if is_raise:
        _say("%s RAISES!  Stake is now %s" % [p["name"], Kit.fmt(stake)], 1.6)
    elif p["seen"]:
        _say("%s: Chaal %s" % [p["name"], Kit.fmt(cost)], 1.2)
    else:
        _say("%s plays Blind %s" % [p["name"], Kit.fmt(cost)], 1.2)
    if p["human"]:
        GameData.mission_event("chaal")
    if pot >= pot_limit:
        forced_show = true
        _say("POT LIMIT reached - showdown!", 2.0)
    _update_pot()
    await _wait(0.6)

func _do_show(p):
    _pay(p, _chaal_cost(p))
    show_requester = p
    ending = true
    _say("%s asks for SHOW!" % p["name"], 2.0)
    await _wait(1.0)

func _do_sideshow(p):
    var tgt = _prev_active(p)
    _pay(p, _chaal_cost(p))
    _say("%s asks %s for a SIDE SHOW" % [p["name"], tgt["name"]], 2.0)
    await _wait(1.0)
    var accept = false
    if tgt["human"]:
        accept = await _ask_sideshow(p)
    else:
        var s = HandEval.strength(_eval(tgt))
        if rm == "muflis":
            s = 1.0 - s
        accept = BotAI.accept_side(tgt, s)
    if not alive:
        return
    if not accept:
        _say("%s refused the side show" % tgt["name"], 1.8)
        await _wait(1.0)
        return
    var ea = _eval(p)
    var eb = _eval(tgt)
    var dd = HandEval.compare(ea, eb, rm)
    var loser = p
    if dd > 0:
        loser = tgt
    if p["human"] or tgt["human"]:
        var other = tgt if p["human"] else p
        var oe = eb if p["human"] else ea
        _say("Side show: %s had %s - %s packs" % [other["name"], HandEval.describe(oe), loser["name"]], 3.0)
    else:
        _say("%s lost the side show" % loser["name"], 2.0)
    await _wait(2.2)
    _do_pack(loser)

func _ask_sideshow(req):
    modal_token += 1
    var tk = modal_token
    var m = _modal(780, "side")
    var vb = m["box"]
    vb.add_child(Kit.label("SIDE SHOW REQUEST", 40, Kit.GOLD))
    vb.add_child(Kit.label("%s wants to compare cards with you.\nThe weaker hand will pack." % req["name"], 28))
    var hb = HBoxContainer.new()
    hb.add_theme_constant_override("separation", 20)
    vb.add_child(hb)
    var a = Kit.button("ACCEPT", Color("2e7d32"), 32, Vector2(0, 80))
    a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    a.pressed.connect(_answer.bind(true))
    hb.add_child(a)
    var d = Kit.button("DENY", Color("c62828"), 32, Vector2(0, 80))
    d.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    d.pressed.connect(_answer.bind(false))
    hb.add_child(d)
    get_tree().create_timer(12.0).timeout.connect(_modal_timeout.bind(tk))
    var ans = await modal_answer
    _close_overlay()
    return ans

func _answer(v):
    modal_token += 1
    modal_answer.emit(v)

func _modal_timeout(tk):
    if tk == modal_token:
        modal_token += 1
        modal_answer.emit(false)

# ------------------------------------------------------------------ turns
func _take_turn(p):
    _set_turn(p)
    if p["human"]:
        await _human_turn(p)
    else:
        await _bot_turn(p)
    _set_turn(null)

func _refresh_buttons(p):
    var cost = _chaal_cost(p)
    var rc = _raise_cost(p)
    var n = _active_count()
    btns["pack"].disabled = false
    btns["see"].disabled = not _can_see(p)
    if rm == "potblind" and round_no < 3 and not p["seen"]:
        btns["see"].text = "SEE\n(Round 3)"
    else:
        btns["see"].text = "SEE CARDS"
    btns["side"].disabled = not _can_side(p)
    btns["show"].disabled = not (n == 2 and p["chips"] >= cost)
    var cl = "CHAAL\n" if p["seen"] else "BLIND\n"
    btns["chaal"].text = cl + Kit.short(cost)
    btns["chaal"].disabled = p["chips"] < cost
    if rc > 0:
        btns["raise"].text = "RAISE\n" + Kit.short(rc)
        btns["raise"].disabled = p["chips"] < rc
    else:
        btns["raise"].text = "RAISE\n(max)"
        btns["raise"].disabled = true

func _human_turn(p):
    _refresh_buttons(p)
    Sfx.play("turn")
    Sfx.vibrate(40)
    timer_total = 25.0
    timer_left = timer_total
    timer_on = true
    while alive:
        var act = await action_chosen
        if not alive:
            return
        if act == "see":
            if _can_see(p):
                _do_see(p)
                _refresh_buttons(p)
            continue
        var ok = false
        if act == "pack":
            ok = true
        elif act == "chaal" and p["chips"] >= _chaal_cost(p):
            ok = true
        elif act == "raise" and _raise_cost(p) > 0 and p["chips"] >= _raise_cost(p):
            ok = true
        elif act == "show" and _active_count() == 2 and p["chips"] >= _chaal_cost(p):
            ok = true
        elif act == "side" and _can_side(p):
            ok = true
        if not ok:
            continue
        timer_on = false
        tbar.value = 0.0
        _set_buttons(false)
        if act == "pack":
            _do_pack(p)
        elif act == "chaal":
            await _do_chaal(p, false)
        elif act == "raise":
            await _do_chaal(p, true)
        elif act == "show":
            await _do_show(p)
        else:
            await _do_sideshow(p)
        break
    timer_on = false
    tbar.value = 0.0
    _set_buttons(false)

func _bot_turn(p):
    await _wait(BotAI.think_time(p))
    if not alive:
        return
    for k in range(3):
        var act = BotAI.decide(p, _ctx(p))
        if act == "see":
            _do_see(p)
            await _wait(0.5)
            continue
        if act == "pack":
            _do_pack(p)
        elif act == "raise":
            await _do_chaal(p, true)
        elif act == "show":
            await _do_show(p)
        elif act == "side":
            await _do_sideshow(p)
        else:
            await _do_chaal(p, false)
        return
    await _do_chaal(p, false)

func _process(delta):
    if timer_on:
        timer_left -= delta
        tbar.value = clampf(timer_left / timer_total, 0.0, 1.0)
        if timer_left <= 0.0:
            timer_on = false
            action_chosen.emit("pack")

# ------------------------------------------------------------------ session / hand
func _session():
    await get_tree().process_frame
    while alive:
        var cont = await _play_hand()
        if not alive:
            return
        if not cont:
            break
    if alive:
        _leave()

func _deal():
    var n = 4 if rm == "bestof4" else 3
    deck = HandEval.new_deck()
    for i in range(n):
        for k in range(players.size()):
            var pi = (dealer + 1 + k) % players.size()
            var p = players[pi]
            if not p["in"]:
                continue
            var cid = deck.pop_back()
            p["cards"].append(cid)
            var cv = CardView.new()
            cv.size = Vector2(130, 190) if pi == 0 else Vector2(66, 94)
            cv.design = GameData.d["design"]
            cv.back_idx = GameData.d["back"]
            cv.card = cid
            cv.position = _pot_pos() - cv.size / 2.0
            add_child(cv)
            p["views"].append(cv)
            all_cards.append(cv)
            var tw = create_tween()
            tw.tween_property(cv, "position", _card_target(pi, i, n), 0.25 * _sc()).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
            Sfx.play("deal")
            await _wait(0.1)
    await _wait(0.3)

func _play_hand():
    if human["chips"] < boot and not tour:
        if GameData.low_bonus_ready():
            var amt = GameData.claim_low_bonus()
            human["chips"] = GameData.d["coins"]
            _say("Free bonus: +%s coins!" % Kit.fmt(amt), 2.5)
            await _wait(1.5)
        if human["chips"] < boot:
            _say("Not enough coins for this table.", 3.0)
            await _wait(2.5)
            return false
    hand_no += 1
    fast = false
    ending = false
    show_requester = null
    forced_show = false
    stake = boot
    pot = 0
    round_no = 1
    _clear_cards()
    var n_in = 0
    for p in players:
        if not p["human"] and not tour and p["chips"] < boot * 60:
            p["chips"] += boot * randi_range(120, 320)
        p["in"] = p["chips"] >= boot
        p["cards"] = []
        p["views"] = []
        p["seen"] = false
        p["packed"] = false
        p["bet"] = 0
        p["ev"] = null
        if p["in"]:
            n_in += 1
        _update_seat(p)
    if tour and not human["in"]:
        await _tour_end()
        return false
    if n_in < 2:
        _say("Not enough players left.", 2.0)
        await _wait(2.0)
        if tour:
            await _tour_end()
        return false
    cur_mode = cfg.get("mode", "classic")
    if cur_mode == "dealer":
        cur_mode = DEALER_POOL[randi() % DEALER_POOL.size()]
    rm = "classic" if cur_mode == "headsup" else cur_mode
    joker_rank = randi_range(2, 14) if rm == "joker" else 0
    lbl_title.text = "%s  |  %s  |  Hand #%d" % [tb["n"], HandEval.mode_info(cur_mode)["name"], hand_no]
    lbl_rule.text = _rule_text()
    dealer = _next_in(dealer)
    for i in range(seats.size()):
        seats[i]["badge"].visible = (i == dealer)
    _update_pot()
    _say("Hand #%d  -  %s" % [hand_no, HandEval.mode_info(cur_mode)["name"]], 1.8)
    for p in players:
        if p["in"]:
            _pay(p, boot)
    await _wait(0.6)
    await _deal()
    if rm == "potblind":
        _say("POT BLIND: no peeking until round 3!", 2.5)
    var turn = _next_active(dealer)
    var safety = 0
    while alive and safety < 500:
        safety += 1
        if _active_count() <= 1 or ending or forced_show:
            break
        if rm == "highlow" and round_no > 4:
            break
        if round_no > 30:
            break
        await _take_turn(players[turn])
        if not alive:
            return false
        if _active_count() <= 1 or ending or forced_show:
            break
        var prev = turn
        turn = _next_active(turn)
        if turn <= prev:
            round_no += 1
            _update_pot()
    if not alive:
        return false
    var cont = await _finish_hand()
    return cont

func _split(winners, lst, amount):
    var each = int(amount / lst.size())
    var rem = amount - each * lst.size()
    for i in range(lst.size()):
        winners.append({"p": lst[i], "amt": each + (rem if i == 0 else 0)})

func _finish_hand():
    timer_on = false
    _set_buttons(false)
    _set_turn(null)
    var act = _active_list()
    var winners = []
    var best = null
    var how = ""
    var best_name = "-"
    if act.size() == 1:
        winners.append({"p": act[0], "amt": pot})
        best = act[0]
        how = "All other players packed"
    else:
        for p in act:
            p["ev"] = _eval(p)
            for v in p["views"]:
                v.flip_to(true)
            _mark_wild(p)
        Sfx.play("flip")
        await _wait(1.3)
        if not alive:
            return false
        best = act[0]
        for p in act:
            if HandEval.compare(p["ev"], best["ev"], rm) > 0:
                best = p
        var tied = []
        for p in act:
            if HandEval.compare(p["ev"], best["ev"], rm) == 0:
                tied.append(p)
        if act.size() == 2 and tied.size() == 2 and show_requester != null:
            var other = tied[0]
            if tied[0]["idx"] == show_requester["idx"]:
                other = tied[1]
            tied = [other]
        if rm == "highlow" and act.size() >= 3:
            var worst = act[0]
            for p in act:
                if HandEval.compare(p["ev"], worst["ev"], rm) < 0:
                    worst = p
            var lows = []
            for p in act:
                if HandEval.compare(p["ev"], worst["ev"], rm) == 0:
                    lows.append(p)
            if HandEval.compare(best["ev"], worst["ev"], rm) == 0:
                _split(winners, act, pot)
            else:
                var half = int(pot / 2)
                _split(winners, tied, half)
                _split(winners, lows, pot - half)
            how = "High-Low split: best and worst hands share the pot"
        else:
            _split(winners, tied, pot)
            how = "Showdown"
        best_name = HandEval.describe(best["ev"])
    var payout = {}
    for w in winners:
        var wp = w["p"]
        wp["chips"] += w["amt"]
        payout[wp["idx"]] = payout.get(wp["idx"], 0) + w["amt"]
        for v in wp["views"]:
            v.glow = true
            v.queue_redraw()
        _chip_fly(_pot_pos(), _seat_center(wp), 5)
    for p in players:
        _update_seat(p)
    if not tour:
        GameData.set_coins(human["chips"])
    var wnames = []
    for w in winners:
        wnames.append(w["p"]["name"])
    var h_pay = payout.get(0, 0)
    var net = h_pay - human["bet"]
    var won = h_pay > 0
    var hev = _eval(human)
    var cat = hev["cat"]
    if hev["special"] > 0:
        cat = 6
    for p in players:
        if p["in"] and not p["human"]:
            GameData.bot_record(p["name"], payout.has(p["idx"]), payout.get(p["idx"], 0) - p["bet"])
    var entry = {"n": hand_no, "mode": HandEval.mode_info(cur_mode)["short"], "table": tb["n"], "pot": pot,
        "win": ", ".join(PackedStringArray(wnames)), "hand": best_name, "net": net}
    session_hist.push_front(entry)
    if human["in"]:
        GameData.finish_hand({"won": won, "net": net, "cat": cat if won else 0, "blind": not human["seen"],
            "show": won and act.size() >= 2, "entry": entry})
    pot = 0
    _update_pot()
    if won:
        Sfx.play("win")
        Sfx.vibrate(120)
        _confetti()
        _say("%s wins!  %s" % [", ".join(PackedStringArray(wnames)), best_name], 3.0)
    else:
        Sfx.play("lose")
        _say("%s wins!  %s" % [", ".join(PackedStringArray(wnames)), best_name], 3.0)
    for w in winners:
        if not w["p"]["human"]:
            _emoji_pop(w["p"]["idx"], [4, 1, 5][randi() % 3])
    await _wait(2.3)
    if not alive:
        return false
    var last = false
    if tour:
        tour_left -= 1
        last = tour_left <= 0
    var cont = await _show_result({"won": won, "net": net, "winners": winners, "how": how, "rows": act, "last": last, "hist": entry})
    if not alive:
        return false
    if tour and (last or not cont):
        if last:
            await _tour_end()
        return false
    return cont

func _confetti():
    var q = GameData.d["settings"]["quality"]
    var cnt = 15 if q == 0 else (40 if q == 1 else 80)
    if not GameData.d["settings"]["anim"]:
        return
    for i in range(cnt):
        var r = ColorRect.new()
        r.size = Vector2(12, 8)
        r.color = Color.from_hsv(randf(), 0.8, 1.0)
        r.position = Vector2(randf() * size.x, -20)
        r.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(r)
        var tw = create_tween()
        tw.tween_property(r, "position:y", size.y + 20, randf_range(1.2, 2.6)).set_delay(randf() * 0.5)
        tw.tween_callback(r.queue_free)

func _emoji_pop(pi, kind):
    if pi >= seats.size():
        return
    var e = EmojiView.new()
    e.kind = kind
    e.size = Vector2(80, 80)
    var rt = seats[pi]["root"]
    e.position = rt.position + Vector2(rt.size.x / 2.0 - 40, -10)
    e.pivot_offset = Vector2(40, 40)
    e.scale = Vector2(0.2, 0.2)
    e.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(e)
    var tw = create_tween()
    tw.tween_property(e, "scale", Vector2(1.2, 1.2), 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(e, "position:y", e.position.y - 50, 1.2)
    tw.parallel().tween_property(e, "modulate:a", 0.0, 0.7).set_delay(0.6)
    tw.tween_callback(e.queue_free)

# ------------------------------------------------------------------ overlays
func _modal(w = 800, kind = "modal"):
    _close_overlay()
    var root = Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_STOP
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.62)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var cc = CenterContainer.new()
    root.add_child(cc)
    cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var pc = PanelContainer.new()
    pc.custom_minimum_size = Vector2(w, 0)
    var st = Kit.sb(Color(0.1, 0.05, 0.22, 0.97), 28, Kit.GOLD, 4, 18)
    st.set_content_margin_all(24)
    pc.add_theme_stylebox_override("panel", st)
    cc.add_child(pc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    pc.add_child(vb)
    overlay = root
    overlay_kind = kind
    return {"root": root, "box": vb}

func _close_overlay():
    if overlay != null and is_instance_valid(overlay):
        overlay.queue_free()
    overlay = null
    overlay_kind = ""

func back_pressed():
    if overlay != null and overlay_kind == "menu":
        _close_overlay()
    elif overlay == null:
        _open_menu()

func _open_menu():
    if overlay != null:
        return
    var m = _modal(620, "menu")
    var vb = m["box"]
    vb.add_child(Kit.label("PAUSED", 44, Kit.GOLD))
    var b = Kit.button("RESUME", Color("2e7d32"), 32, Vector2(0, 76))
    b.pressed.connect(_close_overlay)
    vb.add_child(b)
    var s = Kit.button("SOUND: " + ("ON" if GameData.d["settings"]["sound"] else "OFF"), Color("1565c0"), 28, Vector2(0, 70))
    s.pressed.connect(_toggle_set.bind("sound", s))
    vb.add_child(s)
    var mu = Kit.button("MUSIC: " + ("ON" if GameData.d["settings"]["music"] else "OFF"), Color("6a1b9a"), 28, Vector2(0, 70))
    mu.pressed.connect(_toggle_set.bind("music", mu))
    vb.add_child(mu)
    var r = Kit.label(HandEval.mode_info(cur_mode)["desc"], 22, Color("c8f7ff"))
    r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    r.custom_minimum_size = Vector2(560, 0)
    vb.add_child(r)
    var lv = Kit.button("LEAVE TABLE", Color("c62828"), 28, Vector2(0, 70))
    lv.pressed.connect(_leave)
    vb.add_child(lv)

func _toggle_set(key, btn):
    GameData.d["settings"][key] = not GameData.d["settings"][key]
    GameData.dirty = true
    Sfx.apply_settings()
    var nm = key.to_upper()
    btn.text = nm + ": " + ("ON" if GameData.d["settings"][key] else "OFF")

func _open_history():
    if overlay != null:
        return
    var m = _modal(1100, "hist")
    var vb = m["box"]
    vb.add_child(Kit.label("ROUND HISTORY", 40, Kit.GOLD))
    if session_hist.is_empty():
        vb.add_child(Kit.label("No hands finished yet.", 26))
    var n = 0
    for e in session_hist:
        if n >= 10:
            break
        n += 1
        var net = e["net"]
        var col = Color("7CFC9A") if net >= 0 else Color("ff8a80")
        var t = "#%d  %s  |  Pot %s  |  Winner: %s (%s)  |  You: %s%s" % [e["n"], e["mode"], Kit.short(e["pot"]), e["win"], e["hand"], "+" if net >= 0 else "", Kit.short(net)]
        var l = Kit.label(t, 22, col, HORIZONTAL_ALIGNMENT_LEFT)
        vb.add_child(l)
    var b = Kit.button("CLOSE", Color("7b1fa2"), 30, Vector2(0, 70))
    b.pressed.connect(_close_overlay)
    vb.add_child(b)

func _open_emoji():
    if overlay != null:
        return
    var m = _modal(900, "emoji")
    var vb = m["box"]
    vb.add_child(Kit.label("SEND REACTION", 40, Kit.GOLD))
    var g = GridContainer.new()
    g.columns = 4
    g.add_theme_constant_override("h_separation", 14)
    g.add_theme_constant_override("v_separation", 14)
    vb.add_child(g)
    for i in range(8):
        var b = Button.new()
        b.custom_minimum_size = Vector2(130, 130)
        b.focus_mode = Control.FOCUS_NONE
        b.add_theme_stylebox_override("normal", Kit.sb(Color(1, 1, 1, 0.1), 20))
        b.add_theme_stylebox_override("pressed", Kit.sb(Color(1, 1, 1, 0.3), 20))
        b.add_theme_stylebox_override("hover", Kit.sb(Color(1, 1, 1, 0.2), 20))
        var e = EmojiView.new()
        e.kind = i
        e.size = Vector2(100, 100)
        e.position = Vector2(15, 15)
        e.mouse_filter = Control.MOUSE_FILTER_IGNORE
        b.add_child(e)
        b.pressed.connect(_send_emoji.bind(i))
        g.add_child(b)
    var c = Kit.button("CLOSE", Color("7b1fa2"), 30, Vector2(0, 70))
    c.pressed.connect(_close_overlay)
    vb.add_child(c)

func _send_emoji(k):
    Sfx.play("coin")
    _close_overlay()
    _emoji_pop(0, k)

func _show_result(info):
    var m = _modal(1060, "result")
    var vb = m["box"]
    var net = info["net"]
    var t = ""
    var col = Kit.GOLD
    if info["won"]:
        t = "YOU WIN!  " + ("+" if net >= 0 else "-") + Kit.fmt(absi(net))
    elif not human["in"]:
        t = "You sat out this hand"
        col = Color("c8f7ff")
    else:
        t = "YOU LOST  -" + Kit.fmt(absi(net))
        col = Color("ff8a80")
    vb.add_child(Kit.label(t, 52, col))
    vb.add_child(Kit.label(info["how"], 26, Color("c8f7ff")))
    var win_idx = []
    for w in info["winners"]:
        win_idx.append(w["p"]["idx"])
    var shown = 0
    for p in info["rows"]:
        shown += 1
        var hb = HBoxContainer.new()
        hb.add_theme_constant_override("separation", 14)
        vb.add_child(hb)
        var nm = Kit.label(p["name"], 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        nm.custom_minimum_size = Vector2(190, 0)
        hb.add_child(nm)
        if info["rows"].size() > 1:
            for cid in p["cards"]:
                var cv = CardView.new()
                cv.custom_minimum_size = Vector2(52, 74)
                cv.card = cid
                cv.face_up = true
                cv.design = GameData.d["design"]
                hb.add_child(cv)
            var hn = Kit.label(HandEval.describe(p["ev"]), 26, Color("ffe9a8"), HORIZONTAL_ALIGNMENT_LEFT)
            hn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            hb.add_child(hn)
        else:
            var sp = Control.new()
            sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            hb.add_child(sp)
        if win_idx.has(p["idx"]):
            hb.add_child(Kit.label("WINNER", 26, Color("7CFC9A")))
    var br = HBoxContainer.new()
    br.add_theme_constant_override("separation", 20)
    vb.add_child(br)
    var nb = Kit.button("FINISH" if info["last"] else "NEXT HAND", Color("2e7d32"), 32, Vector2(0, 80))
    nb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    nb.pressed.connect(_result_btn.bind(true))
    br.add_child(nb)
    var lb = Kit.button("LEAVE TABLE", Color("c62828"), 32, Vector2(0, 80))
    lb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    lb.pressed.connect(_result_btn.bind(false))
    br.add_child(lb)
    var cont = await result_closed
    return cont

func _result_btn(v):
    _close_overlay()
    result_closed.emit(v)

func _tour_end():
    var order = players.duplicate()
    order.sort_custom(_by_chips)
    var rank = 1
    for i in range(order.size()):
        if order[i]["idx"] == 0:
            rank = i + 1
    var prize = 0
    if rank == 1:
        prize = tour_fee * 5
    elif rank == 2:
        prize = tour_fee * 3
    elif rank == 3:
        prize = int(tour_fee * 1.5)
    if prize > 0:
        GameData.add_coins(prize)
    if rank == 1:
        GameData.d["tour_wins"] += 1
        GameData.check_achievements()
    GameData.save_game()
    var m = _modal(860, "tour")
    var vb = m["box"]
    vb.add_child(Kit.label("TOURNAMENT RESULT", 42, Kit.GOLD))
    for i in range(order.size()):
        var c = Color.WHITE
        if order[i]["idx"] == 0:
            c = Color("7CFC9A")
        vb.add_child(Kit.label("%d.  %s   -   %s chips" % [i + 1, order[i]["name"], Kit.fmt(order[i]["chips"])], 28, c))
    var res = "You finished #%d" % rank
    if prize > 0:
        res += "   Prize: +" + Kit.fmt(prize)
    vb.add_child(Kit.label(res, 32, Kit.GOLD))
    var b = Kit.button("DONE", Color("2e7d32"), 32, Vector2(0, 80))
    b.pressed.connect(_result_btn.bind(true))
    vb.add_child(b)
    await result_closed

func _by_chips(a, b):
    return a["chips"] > b["chips"]

func _leave():
    if not alive:
        return
    alive = false
    timer_on = false
    if not tour:
        GameData.set_coins(human["chips"])
    GameData.save_game()
    exit_requested.emit()
