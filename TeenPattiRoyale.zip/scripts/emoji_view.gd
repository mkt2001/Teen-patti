extends Control

var kind = 0

func _heart(c, s, col):
    draw_circle(c + Vector2(-0.25 * s, -0.2 * s), 0.3 * s, col)
    draw_circle(c + Vector2(0.25 * s, -0.2 * s), 0.3 * s, col)
    draw_colored_polygon(PackedVector2Array([c + Vector2(-0.52 * s, -0.12 * s), c + Vector2(0.52 * s, -0.12 * s), c + Vector2(0, 0.6 * s)]), col)

func _draw():
    var c = size / 2.0
    var r = minf(size.x, size.y) / 2.0 - 2.0
    var face = Color("ffcc33")
    if kind == 3:
        face = Color("ff7043")
    draw_circle(c, r, Color("b8860b"))
    draw_circle(c, r - 3, face)
    var eye = Color("3b2a10")
    var ex = r * 0.38
    var ey = -r * 0.15
    var le = c + Vector2(-ex, ey)
    var re = c + Vector2(ex, ey)
    if kind == 0:
        draw_circle(le, r * 0.1, eye)
        draw_circle(re, r * 0.1, eye)
        draw_arc(c + Vector2(0, r * 0.1), r * 0.5, deg_to_rad(20), deg_to_rad(160), 16, eye, r * 0.09)
    elif kind == 1:
        draw_arc(le, r * 0.14, deg_to_rad(200), deg_to_rad(340), 8, eye, r * 0.07)
        draw_arc(re, r * 0.14, deg_to_rad(200), deg_to_rad(340), 8, eye, r * 0.07)
        var mp = PackedVector2Array()
        for k in range(0, 13):
            var a = deg_to_rad(k * 15.0)
            mp.append(c + Vector2(0, r * 0.12) + Vector2(cos(a), sin(a)) * r * 0.5)
        draw_colored_polygon(mp, Color("7a1f1f"))
    elif kind == 2:
        draw_circle(le, r * 0.1, eye)
        draw_circle(re, r * 0.1, eye)
        draw_circle(le + Vector2(0, r * 0.35), r * 0.08, Color("4fc3f7"))
        draw_circle(re + Vector2(0, r * 0.35), r * 0.08, Color("4fc3f7"))
        draw_arc(c + Vector2(0, r * 0.6), r * 0.35, deg_to_rad(200), deg_to_rad(340), 12, eye, r * 0.08)
    elif kind == 3:
        draw_circle(le, r * 0.1, eye)
        draw_circle(re, r * 0.1, eye)
        draw_line(le + Vector2(-r * 0.2, -r * 0.2), le + Vector2(r * 0.2, -r * 0.05), eye, r * 0.08)
        draw_line(re + Vector2(r * 0.2, -r * 0.2), re + Vector2(-r * 0.2, -r * 0.05), eye, r * 0.08)
        draw_arc(c + Vector2(0, r * 0.55), r * 0.3, deg_to_rad(200), deg_to_rad(340), 12, eye, r * 0.08)
    elif kind == 4:
        draw_rect(Rect2(le + Vector2(-r * 0.25, -r * 0.12), Vector2(r * 0.5, r * 0.3)), Color("111111"))
        draw_rect(Rect2(re + Vector2(-r * 0.25, -r * 0.12), Vector2(r * 0.5, r * 0.3)), Color("111111"))
        draw_line(le + Vector2(r * 0.25, 0), re + Vector2(-r * 0.25, 0), Color("111111"), r * 0.08)
        draw_arc(c + Vector2(0, r * 0.1), r * 0.5, deg_to_rad(20), deg_to_rad(160), 16, eye, r * 0.09)
    elif kind == 5:
        _heart(le, r * 0.35, Color("e53935"))
        _heart(re, r * 0.35, Color("e53935"))
        draw_arc(c + Vector2(0, r * 0.1), r * 0.5, deg_to_rad(20), deg_to_rad(160), 16, eye, r * 0.09)
    elif kind == 6:
        draw_circle(le, r * 0.16, Color.WHITE)
        draw_circle(re, r * 0.16, Color.WHITE)
        draw_circle(le, r * 0.07, eye)
        draw_circle(re, r * 0.07, eye)
        draw_circle(c + Vector2(0, r * 0.45), r * 0.16, Color("5a2a1a"))
    else:
        draw_circle(le, r * 0.1, eye)
        draw_arc(re, r * 0.14, deg_to_rad(200), deg_to_rad(340), 8, eye, r * 0.07)
        draw_arc(c + Vector2(0, r * 0.1), r * 0.5, deg_to_rad(20), deg_to_rad(160), 16, eye, r * 0.09)
        draw_circle(c + Vector2(r * 0.15, r * 0.62), r * 0.14, Color("ef6c8a"))
