extends RefCounted

const DIFF_NAMES = ["Beginner", "Easy", "Medium", "Hard", "Expert", "Master", "Professional"]
const NOISE = [0.40, 0.30, 0.22, 0.15, 0.10, 0.06, 0.03]

const ROSTER = [
    {"n": "Rajan", "a": 4, "p": "Aggressive"}, {"n": "Priya", "a": 5, "p": "Calm"},
    {"n": "Vikram", "a": 6, "p": "Bluffer"}, {"n": "Simran", "a": 7, "p": "Tight"},
    {"n": "Arjun", "a": 8, "p": "Gambler"}, {"n": "Meera", "a": 9, "p": "Balanced"},
    {"n": "Karan", "a": 10, "p": "Aggressive"}, {"n": "Anita", "a": 11, "p": "Cautious"},
    {"n": "Rohit", "a": 0, "p": "Bluffer"}, {"n": "Neha", "a": 1, "p": "Balanced"},
    {"n": "Sameer", "a": 2, "p": "Calm"}, {"n": "Pooja", "a": 3, "p": "Gambler"},
    {"n": "Imran", "a": 6, "p": "Tight"}, {"n": "Kavya", "a": 5, "p": "Aggressive"},
    {"n": "Deepak", "a": 8, "p": "Cautious"}, {"n": "Isha", "a": 9, "p": "Bluffer"}
]

const PERS = {
    "Aggressive": {"aggr": 0.85, "bluff": 0.25, "tight": 0.05, "blind": 0.5},
    "Calm": {"aggr": 0.4, "bluff": 0.1, "tight": 0.25, "blind": 0.3},
    "Bluffer": {"aggr": 0.6, "bluff": 0.55, "tight": 0.1, "blind": 0.4},
    "Tight": {"aggr": 0.3, "bluff": 0.08, "tight": 0.5, "blind": 0.15},
    "Gambler": {"aggr": 0.75, "bluff": 0.35, "tight": 0.0, "blind": 0.8},
    "Balanced": {"aggr": 0.5, "bluff": 0.2, "tight": 0.2, "blind": 0.35},
    "Cautious": {"aggr": 0.25, "bluff": 0.05, "tight": 0.45, "blind": 0.2}
}

static func pick(n):
    var idx = range(ROSTER.size())
    idx.shuffle()
    var out = []
    for i in range(n):
        out.append(ROSTER[idx[i]])
    return out

static func think_time(p):
    var base = randf_range(0.9, 2.3)
    return base * (1.0 - 0.07 * p["diff"])

static func decide(p, c):
    var pers = PERS[p["pers"]]
    var chips = p["chips"]
    var cost = c["chaal"]
    var rc = c["raise"]
    if not p["seen"]:
        if c["can_see"]:
            var see_p = 0.10 + c["round"] * 0.12 + (1.0 - pers["blind"]) * 0.25
            if cost * 6 > chips:
                see_p += 0.3
            if randf() < see_p:
                return "see"
        if cost > chips:
            return "pack"
        if c["can_show"] and randf() < 0.12 + 0.1 * pers["aggr"]:
            return "show"
        if rc > 0 and rc <= chips and randf() < pers["aggr"] * 0.25:
            return "raise"
        return "chaal"
    var noise = NOISE[p["diff"]]
    var eff = clampf(c["strength"] + randf_range(-noise, noise), 0.0, 1.0)
    if cost > chips:
        return "pack"
    var fold_thr = 0.30 + 0.025 * c["round"] + pers["tight"] * 0.25
    if cost * 10 > chips:
        fold_thr += 0.15
    var bluff_chance = pers["bluff"] * 0.6
    if c["active"] == 2:
        bluff_chance += 0.15
        fold_thr -= 0.08
    if eff < fold_thr and randf() > bluff_chance:
        return "pack"
    if c["can_show"] and eff >= 0.5:
        var sp = 0.25 + pers["aggr"] * 0.3
        if c["round"] >= 4:
            sp += 0.3
        if randf() < sp:
            return "show"
    if c["can_side"] and eff >= 0.4 and randf() < 0.25:
        return "side"
    var raise_thr = 0.62 - pers["aggr"] * 0.2
    if rc > 0 and rc <= chips * 0.2 and eff > raise_thr and randf() < 0.3 + pers["aggr"] * 0.4:
        return "raise"
    return "chaal"

static func accept_side(p, s):
    var pers = PERS[p["pers"]]
    var eff = clampf(s + randf_range(-NOISE[p["diff"]], NOISE[p["diff"]]), 0.0, 1.0)
    if eff > 0.55:
        return randf() < 0.85
    if eff > 0.35:
        return randf() < 0.5 + pers["bluff"] * 0.3
    return randf() < 0.25 + pers["bluff"] * 0.4
