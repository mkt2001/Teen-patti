extends Node

signal coins_changed
signal notify(msg)

const Kit = preload("res://scripts/ui_kit.gd")

const SAVE_PATH = "user://teenpatti_save.dat"
const BACKUP_PATH = "user://teenpatti_save.bak"
const SALT = "TPR-Offline-Royale-2026"
const START_COINS = 100000000

const TABLES = [
    {"n": "Beginner Table", "boot": 500, "dmin": 0, "dmax": 1},
    {"n": "Silver Table", "boot": 5000, "dmin": 1, "dmax": 2},
    {"n": "Gold Table", "boot": 50000, "dmin": 2, "dmax": 3},
    {"n": "Diamond Table", "boot": 250000, "dmin": 3, "dmax": 4},
    {"n": "Platinum Table", "boot": 1000000, "dmin": 4, "dmax": 5},
    {"n": "Royal Table", "boot": 2500000, "dmin": 5, "dmax": 5},
    {"n": "VIP Table", "boot": 5000000, "dmin": 5, "dmax": 6},
    {"n": "Elite Table", "boot": 10000000, "dmin": 6, "dmax": 6}
]

const CARD_DESIGNS = [
    {"n": "Classic White", "p": 0, "lv": 1}, {"n": "Ivory Gold", "p": 2000000, "lv": 2},
    {"n": "Royal Blue", "p": 5000000, "lv": 3}, {"n": "Midnight", "p": 10000000, "lv": 5},
    {"n": "Rose Quartz", "p": 20000000, "lv": 8}, {"n": "Emerald (Achievement)", "p": -1, "lv": 1}
]
const CARD_BACKS = [
    {"n": "Royal Red", "p": 0, "lv": 1}, {"n": "Ocean Blue", "p": 1000000, "lv": 1},
    {"n": "Emerald Green", "p": 2000000, "lv": 2}, {"n": "Violet Crown", "p": 5000000, "lv": 4},
    {"n": "Black Gold", "p": 15000000, "lv": 6}, {"n": "Diamond Teal", "p": 30000000, "lv": 10}
]
const THEME_ITEMS = [
    {"n": "Emerald Felt", "p": 0, "lv": 1}, {"n": "Royal Red", "p": 3000000, "lv": 2},
    {"n": "Sapphire Blue", "p": 5000000, "lv": 3}, {"n": "Purple Night", "p": 10000000, "lv": 5},
    {"n": "Black and Gold", "p": 25000000, "lv": 8}, {"n": "Ocean Teal (Achievement)", "p": -1, "lv": 1}
]
const AVATARS = [
    {"n": "Classic", "p": 0, "lv": 1}, {"n": "Sunny", "p": 0, "lv": 1},
    {"n": "Ruby", "p": 0, "lv": 1}, {"n": "Sky", "p": 0, "lv": 1},
    {"n": "Neon", "p": 1000000, "lv": 2}, {"n": "Royal", "p": 2000000, "lv": 3},
    {"n": "Ninja", "p": 4000000, "lv": 4}, {"n": "Queen", "p": 6000000, "lv": 5},
    {"n": "Champion", "p": 10000000, "lv": 7}, {"n": "Boss", "p": 20000000, "lv": 9},
    {"n": "Legend", "p": 30000000, "lv": 12}, {"n": "Emperor", "p": 50000000, "lv": 15}
]
const FRAMES = [
    {"n": "None", "p": 0, "lv": 1}, {"n": "Bronze", "p": 1000000, "lv": 2},
    {"n": "Silver", "p": 3000000, "lv": 4}, {"n": "Gold VIP", "p": 10000000, "lv": 6},
    {"n": "Diamond VIP", "p": 30000000, "lv": 10}, {"n": "Royal Purple", "p": 60000000, "lv": 15},
    {"n": "Rainbow (Achievement)", "p": -1, "lv": 1}
]

const ACHIEVEMENTS = [
    {"id": "a_play1", "t": "Play your first hand", "stat": "played", "n": 1, "r": 500000},
    {"id": "a_play10", "t": "Play 10 hands", "stat": "played", "n": 10, "r": 2000000},
    {"id": "a_play50", "t": "Play 50 hands", "stat": "played", "n": 50, "r": 10000000},
    {"id": "a_play200", "t": "Play 200 hands", "stat": "played", "n": 200, "r": 40000000},
    {"id": "a_win1", "t": "Win your first hand", "stat": "won", "n": 1, "r": 1000000},
    {"id": "a_win10", "t": "Win 10 hands", "stat": "won", "n": 10, "r": 5000000},
    {"id": "a_win50", "t": "Win 50 hands (unlocks Emerald cards)", "stat": "won", "n": 50, "r": 20000000, "grant": "cd_5"},
    {"id": "a_win200", "t": "Win 200 hands", "stat": "won", "n": 200, "r": 80000000},
    {"id": "a_big1", "t": "Win 10 L in one hand", "stat": "biggest_win", "n": 1000000, "r": 2000000},
    {"id": "a_big2", "t": "Win 1 Cr in one hand", "stat": "biggest_win", "n": 10000000, "r": 10000000},
    {"id": "a_big3", "t": "Win 5 Cr in one hand", "stat": "biggest_win", "n": 50000000, "r": 30000000},
    {"id": "a_trail1", "t": "Win with a Trail", "stat": "trails", "n": 1, "r": 5000000},
    {"id": "a_trail5", "t": "Win with 5 Trails", "stat": "trails", "n": 5, "r": 25000000},
    {"id": "a_streak3", "t": "Win 3 hands in a row", "stat": "best_streak", "n": 3, "r": 3000000},
    {"id": "a_level5", "t": "Reach level 5", "stat": "level", "n": 5, "r": 5000000},
    {"id": "a_level10", "t": "Reach level 10 (unlocks Ocean Teal table)", "stat": "level", "n": 10, "r": 15000000, "grant": "th_5"},
    {"id": "a_level25", "t": "Reach level 25 (unlocks Rainbow frame)", "stat": "level", "n": 25, "r": 60000000, "grant": "fr_6"},
    {"id": "a_login7", "t": "7 day login streak", "stat": "login_streak", "n": 7, "r": 10000000},
    {"id": "a_tour1", "t": "Win a tournament", "stat": "tour_wins", "n": 1, "r": 20000000},
    {"id": "a_rich", "t": "Hold 20 Cr coins", "stat": "coins", "n": 200000000, "r": 20000000}
]

const MISSION_DEFS = {
    "d_play": {"t": "Play 3 hands", "k": "play", "n": 3, "r": 500000},
    "d_win": {"t": "Win 2 hands", "k": "win", "n": 2, "r": 1000000},
    "d_chaal": {"t": "Make 10 chaals", "k": "chaal", "n": 10, "r": 400000},
    "d_show": {"t": "Win a showdown", "k": "showwin", "n": 1, "r": 800000},
    "d_pair": {"t": "Win with a Pair or better", "k": "winpair", "n": 1, "r": 800000},
    "d_blind": {"t": "Win a hand playing blind", "k": "blindwin", "n": 1, "r": 1500000},
    "d_coins": {"t": "Win 50 L coins in total", "k": "coins", "n": 5000000, "r": 1000000},
    "w_play": {"t": "Play 25 hands", "k": "play", "n": 25, "r": 5000000},
    "w_win": {"t": "Win 12 hands", "k": "win", "n": 12, "r": 8000000},
    "w_coins": {"t": "Win 10 Cr coins in total", "k": "coins", "n": 100000000, "r": 15000000},
    "w_rare": {"t": "Win 3 times with Pure Sequence or Trail", "k": "rare", "n": 3, "r": 20000000},
    "w_chaal": {"t": "Make 80 chaals", "k": "chaal", "n": 80, "r": 6000000},
    "w_pack": {"t": "Pack 15 times (smart folding)", "k": "pack", "n": 15, "r": 4000000}
}
const DAILY_IDS = ["d_play", "d_win", "d_chaal", "d_show", "d_pair", "d_blind", "d_coins"]
const WEEKLY_IDS = ["w_play", "w_win", "w_coins", "w_rare", "w_chaal", "w_pack"]
const DAILY_REWARDS = [500000, 1000000, 1500000, 2500000, 4000000, 6000000, 10000000]
const SPIN_PRIZES = [100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000, 25000000]
const SPIN_W = [30.0, 25.0, 20.0, 12.0, 7.0, 4.0, 1.5, 0.5]

const TR = {
    "play_now": ["PLAY NOW", "ABHI KHELO"], "quick": ["QUICK PLAY", "JALDI KHELO"],
    "vs_ai": ["PLAY WITH AI", "AI KE SAATH"], "mode": ["GAME MODE", "GAME MODE"],
    "table": ["SELECT TABLE", "TABLE CHUNO"], "wallet": ["MY WALLET", "MERA WALLET"],
    "daily": ["DAILY REWARDS", "DAILY INAAM"], "spin": ["LUCKY SPIN", "LUCKY SPIN"],
    "ach": ["ACHIEVEMENTS", "UPLABDHIYAN"], "stats": ["GAME STATISTICS", "STATISTICS"],
    "settings": ["SETTINGS", "SETTINGS"], "profile": ["PROFILE", "PROFILE"],
    "how": ["HOW TO PLAY", "KAISE KHELEIN"], "missions": ["MISSIONS", "MISSIONS"],
    "tour": ["TOURNAMENT", "TOURNAMENT"], "shop": ["SHOP", "SHOP"],
    "board": ["LEADERBOARD", "LEADERBOARD"], "history": ["HISTORY", "ITIHAAS"],
    "back": ["BACK", "WAPAS"]
}

var d = {}
var dirty = false
var _acc = 0.0

func _ready():
    d = _defaults()
    load_game()
    refresh_missions()

func _process(delta):
    _acc += delta
    if _acc > 15.0:
        _acc = 0.0
        if dirty:
            save_game()

func _notification(what):
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        save_game()

func T(k):
    var l = clampi(int(d["settings"]["lang"]), 0, 1)
    if TR.has(k):
        return TR[k][l]
    return k

func _defaults():
    return {
        "name": "Player", "avatar": 0, "frame": 0, "design": 0, "back": 0, "theme": 0,
        "coins": START_COINS, "xp": 0, "level": 1,
        "played": 0, "won": 0, "lost": 0, "biggest_win": 0, "total_won": 0, "total_lost": 0,
        "trails": 0, "packs": 0, "win_streak": 0, "best_streak": 0, "tour_wins": 0, "login_streak": 0,
        "welcome": false, "last_login_day": -1, "last_spin_day": -1, "last_low_time": 0,
        "owned": _default_owned(), "ach": {},
        "missions": {"day": -1, "week": -1, "daily": [], "weekly": []},
        "history": [], "bots": {},
        "last_mode": "classic", "last_table": 0, "bots_n": 4, "diff": -1,
        "settings": {"sound": true, "music": true, "vib": true, "quality": 2, "anim": true, "lang": 0, "dark": true}
    }

func _default_owned():
    return {"cd_0": true, "cb_0": true, "th_0": true, "av_0": true, "av_1": true, "av_2": true, "av_3": true, "fr_0": true}

func _merge(base, over):
    for k in over.keys():
        if base.has(k) and typeof(base[k]) == TYPE_DICTIONARY and typeof(over[k]) == TYPE_DICTIONARY and k != "owned" and k != "ach" and k != "bots":
            _merge(base[k], over[k])
        else:
            base[k] = over[k]
    return base

func _intify(v):
    var t = typeof(v)
    if t == TYPE_FLOAT:
        if v == floor(v) and absf(v) < 1.0e15:
            return int(v)
        return v
    if t == TYPE_DICTIONARY:
        for k in v.keys():
            v[k] = _intify(v[k])
        return v
    if t == TYPE_ARRAY:
        for i in range(v.size()):
            v[i] = _intify(v[i])
        return v
    return v

func save_game():
    if d.is_empty():
        return
    dirty = false
    var js = JSON.stringify(d)
    var wrap = JSON.stringify({"d": js, "s": (js + SALT).sha256_text()})
    for path in [SAVE_PATH, BACKUP_PATH]:
        var f = FileAccess.open(path, FileAccess.WRITE)
        if f != null:
            f.store_string(wrap)
            f.close()

func _read(path):
    if not FileAccess.file_exists(path):
        return null
    var f = FileAccess.open(path, FileAccess.READ)
    if f == null:
        return null
    var txt = f.get_as_text()
    f.close()
    var wrap = JSON.parse_string(txt)
    if typeof(wrap) != TYPE_DICTIONARY:
        return null
    if not wrap.has("d") or not wrap.has("s"):
        return null
    if (str(wrap["d"]) + SALT).sha256_text() != str(wrap["s"]):
        return null
    var data = JSON.parse_string(str(wrap["d"]))
    if typeof(data) != TYPE_DICTIONARY:
        return null
    return data

func load_game():
    var data = _read(SAVE_PATH)
    if data == null:
        data = _read(BACKUP_PATH)
    if data == null:
        save_game()
        return
    data = _intify(data)
    d = _merge(_defaults(), data)
    var own = _default_owned()
    for k in own.keys():
        d["owned"][k] = true
    d["coins"] = maxi(0, int(d["coins"]))

func reset_progress():
    var st = d["settings"]
    d = _defaults()
    d["settings"] = st
    d["welcome"] = true
    refresh_missions()
    save_game()
    coins_changed.emit()

# ---------- coins / xp ----------
func set_coins(n):
    d["coins"] = maxi(0, int(n))
    dirty = true
    coins_changed.emit()

func add_coins(n):
    set_coins(d["coins"] + int(n))

func xp_need(lv):
    return 200 + lv * 150

func add_xp(n):
    d["xp"] += n
    while d["xp"] >= xp_need(d["level"]):
        d["xp"] -= xp_need(d["level"])
        d["level"] += 1
        var r = d["level"] * 250000
        d["coins"] += r
        notify.emit("LEVEL UP!  Level %d   +%s coins" % [d["level"], Kit.fmt(r)])
        Sfx.play("levelup")
    dirty = true
    coins_changed.emit()
    check_achievements()

# ---------- daily rewards ----------
func today():
    return int(Time.get_unix_time_from_system() / 86400.0)

func can_claim_daily():
    return d["last_login_day"] != today()

func next_streak():
    if d["last_login_day"] == today() - 1:
        return d["login_streak"] + 1
    return 1

func claim_welcome():
    if d["welcome"]:
        return 0
    d["welcome"] = true
    add_coins(2500000)
    save_game()
    return 2500000

func claim_daily():
    if not can_claim_daily():
        return 0
    var st = next_streak()
    d["login_streak"] = st
    d["last_login_day"] = today()
    var r = DAILY_REWARDS[(st - 1) % 7]
    add_coins(r)
    check_achievements()
    save_game()
    return r

func spin_available():
    return d["last_spin_day"] != today()

func pick_spin():
    var tot = 0.0
    for w in SPIN_W:
        tot += w
    var x = randf() * tot
    for i in range(SPIN_W.size()):
        x -= SPIN_W[i]
        if x <= 0.0:
            return i
    return 0

func finish_spin(idx):
    d["last_spin_day"] = today()
    add_coins(SPIN_PRIZES[idx])
    save_game()

func low_bonus_ready():
    return d["coins"] < 100000 and Time.get_unix_time_from_system() - float(d["last_low_time"]) > 300.0

func claim_low_bonus():
    d["last_low_time"] = int(Time.get_unix_time_from_system())
    add_coins(2000000)
    save_game()
    return 2000000

# ---------- missions ----------
func refresh_missions():
    var m = d["missions"]
    var day = today()
    var wk = int(day / 7)
    if m["day"] != day:
        m["day"] = day
        m["daily"] = []
        for k in range(3):
            m["daily"].append({"id": DAILY_IDS[(day + k * 2) % DAILY_IDS.size()], "p": 0, "c": false})
    if m["week"] != wk:
        m["week"] = wk
        m["weekly"] = []
        for k in range(3):
            m["weekly"].append({"id": WEEKLY_IDS[(wk + k * 2) % WEEKLY_IDS.size()], "p": 0, "c": false})
    dirty = true

func mission_event(kind, amount = 1):
    refresh_missions()
    for lst in [d["missions"]["daily"], d["missions"]["weekly"]]:
        for it in lst:
            var df = MISSION_DEFS[it["id"]]
            if df["k"] == kind and not it["c"]:
                it["p"] = mini(df["n"], it["p"] + amount)
    dirty = true

func claim_mission(it):
    var df = MISSION_DEFS[it["id"]]
    if it["c"] or it["p"] < df["n"]:
        return false
    it["c"] = true
    add_coins(df["r"])
    add_xp(25)
    save_game()
    return true

# ---------- achievements ----------
func stat_value(s):
    if s == "coins":
        return d["coins"]
    return d.get(s, 0)

func check_achievements():
    for a in ACHIEVEMENTS:
        if d["ach"].get(a["id"], 0) == 0 and stat_value(a["stat"]) >= a["n"]:
            d["ach"][a["id"]] = 1
            notify.emit("Achievement ready: " + a["t"])
    dirty = true

func claim_ach(a):
    if d["ach"].get(a["id"], 0) != 1:
        return false
    d["ach"][a["id"]] = 2
    add_coins(a["r"])
    if a.has("grant"):
        d["owned"][a["grant"]] = true
    save_game()
    return true

# ---------- hands ----------
func finish_hand(info):
    d["played"] += 1
    var net = info["net"]
    if info["won"]:
        d["won"] += 1
        d["win_streak"] += 1
        if d["win_streak"] > d["best_streak"]:
            d["best_streak"] = d["win_streak"]
        if net > 0:
            d["total_won"] += net
            if net > d["biggest_win"]:
                d["biggest_win"] = net
        if info["cat"] == 6:
            d["trails"] += 1
    else:
        d["lost"] += 1
        d["win_streak"] = 0
        if net < 0:
            d["total_lost"] += -net
    mission_event("play")
    if info["won"]:
        mission_event("win")
        if net > 0:
            mission_event("coins", net)
        if info["blind"]:
            mission_event("blindwin")
        if info["cat"] >= 2:
            mission_event("winpair")
        if info["cat"] >= 5:
            mission_event("rare")
        if info["show"]:
            mission_event("showwin")
    d["history"].push_front(info["entry"])
    while d["history"].size() > 80:
        d["history"].pop_back()
    add_xp(35 if info["won"] else 10)
    save_game()

func bot_record(nm, won, net):
    if not d["bots"].has(nm):
        d["bots"][nm] = {"p": 0, "w": 0, "e": 0}
    var b = d["bots"][nm]
    b["p"] += 1
    if won:
        b["w"] += 1
    if net > 0:
        b["e"] += net
    dirty = true

func leaderboard():
    var out = [{"name": d["name"], "e": d["total_won"], "w": d["won"], "p": d["played"], "you": true}]
    for r in ["Rajan", "Priya", "Vikram", "Simran", "Arjun", "Meera", "Karan", "Anita", "Rohit", "Neha", "Sameer", "Pooja", "Imran", "Kavya", "Deepak", "Isha"]:
        var b = d["bots"].get(r, {"p": 0, "w": 0, "e": 0})
        out.append({"name": r, "e": b["e"], "w": b["w"], "p": b["p"], "you": false})
    out.sort_custom(_lb_sort)
    return out

func _lb_sort(a, b):
    return a["e"] > b["e"]

# ---------- shop ----------
func cat_list(cat):
    if cat == "cd":
        return CARD_DESIGNS
    if cat == "cb":
        return CARD_BACKS
    if cat == "th":
        return THEME_ITEMS
    if cat == "av":
        return AVATARS
    return FRAMES

func cat_key(cat):
    if cat == "cd":
        return "design"
    if cat == "cb":
        return "back"
    if cat == "th":
        return "theme"
    if cat == "av":
        return "avatar"
    return "frame"

func owns(cat, idx):
    return d["owned"].get(cat + "_" + str(idx), false)

func equip(cat, idx):
    if owns(cat, idx):
        d[cat_key(cat)] = idx
        dirty = true
        save_game()

func buy(cat, idx):
    var it = cat_list(cat)[idx]
    if owns(cat, idx):
        equip(cat, idx)
        return "Equipped"
    if it["p"] < 0:
        return "Unlock this through an achievement"
    if d["level"] < it["lv"]:
        return "Reach level %d first" % it["lv"]
    if d["coins"] < it["p"]:
        return "Not enough coins"
    d["coins"] -= it["p"]
    d["owned"][cat + "_" + str(idx)] = true
    d[cat_key(cat)] = idx
    coins_changed.emit()
    save_game()
    Sfx.play("coin")
    return "Purchased!"
