extends RefCounted

const HIGH = 1
const PAIR = 2
const COLOR = 3
const SEQ = 4
const PSEQ = 5
const TRAIL = 6

const MODES = [
    {"id": "classic", "name": "Classic Teen Patti", "short": "Classic", "desc": "The original game. Trail > Pure Sequence > Sequence > Color > Pair > High Card. Highest hand wins."},
    {"id": "muflis", "name": "Muflis", "short": "Muflis", "desc": "Lowest hand wins! Rankings are reversed: High Card beats Pair, Trail is the worst hand."},
    {"id": "ak47", "name": "AK47", "short": "AK47", "desc": "All Aces, Kings, 4s and 7s are Jokers and act as any card."},
    {"id": "joker", "name": "Joker", "short": "Joker", "desc": "A random Joker rank is picked every hand. All cards of that rank are wild."},
    {"id": "n999", "name": "999", "short": "999", "desc": "All 9s are wild. A natural 9-9-9 is the supreme hand and beats everything."},
    {"id": "lowjoker", "name": "Lowest Joker", "short": "Low Joker", "desc": "The lowest card in your own hand becomes your Joker."},
    {"id": "bestof4", "name": "Best of Four", "short": "Best of 4", "desc": "Everyone gets 4 cards. Your best 3-card hand counts."},
    {"id": "n235", "name": "2-3-5", "short": "2-3-5", "desc": "A mixed-suit 2-3-5 is the supreme hand and even beats a Trail."},
    {"id": "n432", "name": "4-3-2", "short": "4-3-2", "desc": "A 4-3-2 of any suits beats a Pure Sequence but loses to a Trail."},
    {"id": "potblind", "name": "Pot Blind", "short": "Pot Blind", "desc": "Nobody may look at cards until round 3. Everyone plays blind first!"},
    {"id": "ak47v", "name": "AK47 Variation", "short": "AK47 Var", "desc": "A, K, 4 and 7 are Jokers, but a natural hand beats a Joker-made hand of equal value."},
    {"id": "dealer", "name": "Dealer's Choice", "short": "Dealer", "desc": "A random variation is picked for every hand. Expect surprises!"},
    {"id": "headsup", "name": "Heads Up", "short": "Heads Up", "desc": "You against one bot. Classic rules, no side show, quick duels."},
    {"id": "highlow", "name": "High-Low", "short": "High-Low", "desc": "Four betting rounds. At showdown the pot is split between the best and the worst hand."}
]

const CUM = {1: 0.0, 2: 0.7439, 3: 0.9133, 4: 0.9629, 5: 0.9955, 6: 0.9977}
const SPAN = {1: 0.7439, 2: 0.1694, 3: 0.0496, 4: 0.0326, 5: 0.0022, 6: 0.0023}

static func rank_of(c):
    return c % 13 + 2

static func suit_of(c):
    return c / 13

static func rank_str(r):
    if r <= 10:
        return str(r)
    return ["J", "Q", "K", "A"][r - 11]

static func rank_word(r):
    if r <= 10:
        return str(r)
    return ["Jack", "Queen", "King", "Ace"][r - 11]

static func mode_info(id):
    for m in MODES:
        if m["id"] == id:
            return m
    return MODES[0]

static func new_deck():
    var d = range(52)
    d.shuffle()
    return d

static func _s3(c0, c1, c2):
    var rs = [rank_of(c0), rank_of(c1), rank_of(c2)]
    rs.sort()
    rs.reverse()
    var a = rs[0]
    var b = rs[1]
    var c = rs[2]
    var s0 = suit_of(c0)
    var flush = (s0 == suit_of(c1) and s0 == suit_of(c2))
    var seq = false
    var top = 0
    if a - 1 == b and b - 1 == c:
        seq = true
        top = a
    elif a == 14 and b == 3 and c == 2:
        seq = true
        top = 15
    if a == b and b == c:
        return TRAIL * 1000000 + a * 10000
    if seq and flush:
        return PSEQ * 1000000 + top * 10000
    if seq:
        return SEQ * 1000000 + top * 10000
    if flush:
        return COLOR * 1000000 + a * 10000 + b * 100 + c
    if a == b:
        return PAIR * 1000000 + a * 10000 + c * 100
    if b == c:
        return PAIR * 1000000 + b * 10000 + a * 100
    return HIGH * 1000000 + a * 10000 + b * 100 + c

static func _best(fixed, nwild):
    if nwild == 0:
        return _s3(fixed[0], fixed[1], fixed[2])
    if nwild >= 3:
        return TRAIL * 1000000 + 14 * 10000
    var best = 0
    if nwild == 1:
        for w in range(52):
            var sc = _s3(fixed[0], fixed[1], w)
            if sc > best:
                best = sc
        return best
    for w in range(52):
        for x in range(w, 52):
            var sc2 = _s3(fixed[0], w, x)
            if sc2 > best:
                best = sc2
    return best

static func wild_flags(cards, mode, ctx = {}):
    var f = []
    for i in range(cards.size()):
        f.append(false)
    if mode == "ak47" or mode == "ak47v":
        for i in range(cards.size()):
            var r = rank_of(cards[i])
            f[i] = (r == 14 or r == 13 or r == 4 or r == 7)
    elif mode == "joker":
        var jr = ctx.get("joker", 0)
        for i in range(cards.size()):
            f[i] = (rank_of(cards[i]) == jr)
    elif mode == "n999":
        for i in range(cards.size()):
            f[i] = (rank_of(cards[i]) == 9)
    elif mode == "lowjoker":
        var li = 0
        for i in range(cards.size()):
            if rank_of(cards[i]) < rank_of(cards[li]):
                li = i
        f[li] = true
    return f

static func evaluate(cards, mode, ctx = {}):
    if cards.size() > 3:
        var best = {}
        for skip in range(cards.size()):
            var sub = []
            for i in range(cards.size()):
                if i != skip:
                    sub.append(cards[i])
            var e = evaluate(sub, mode, ctx)
            if best.is_empty() or e["key"] > best["key"]:
                best = e
        return best
    var flags = wild_flags(cards, mode, ctx)
    var fixed = []
    var nwild = 0
    for i in range(3):
        if flags[i]:
            nwild += 1
        else:
            fixed.append(cards[i])
    var score = _best(fixed, nwild)
    var special = 0
    var key = score * 10
    var rs = [rank_of(cards[0]), rank_of(cards[1]), rank_of(cards[2])]
    rs.sort()
    var same_suit = (suit_of(cards[0]) == suit_of(cards[1]) and suit_of(cards[1]) == suit_of(cards[2]))
    if mode == "n235" and rs == [2, 3, 5] and not same_suit:
        special = 1
        key = 70000000
    elif mode == "n432" and rs == [2, 3, 4]:
        special = 2
        key = 55000000
    elif mode == "n999" and nwild == 3:
        special = 3
        key = 80000000
    elif mode == "ak47v" and nwild == 0:
        key += 1
    return {"key": key, "score": score, "cat": score / 1000000, "special": special, "wild": nwild, "cards": cards, "flags": flags}

static func compare(a, b, mode):
    var d = a["key"] - b["key"]
    if mode == "muflis":
        d = -d
    return d

static func describe(ev):
    var sp = ev["special"]
    if sp == 1:
        return "2-3-5 Supreme"
    if sp == 2:
        return "4-3-2 Special"
    if sp == 3:
        return "Triple Nine"
    var cat = ev["cat"]
    var sc = ev["score"] % 1000000
    var a = sc / 10000
    if cat == TRAIL:
        return "Trail of " + rank_word(a) + "s"
    if cat == PSEQ:
        return "Pure Sequence"
    if cat == SEQ:
        return "Sequence"
    if cat == COLOR:
        return "Color (" + rank_str(a) + " high)"
    if cat == PAIR:
        return "Pair of " + rank_word(a) + "s"
    return "High Card " + rank_word(a)

static func strength(ev):
    if ev["special"] > 0:
        return 0.999
    var cat = ev["cat"]
    var sc = ev["score"] % 1000000
    var a = sc / 10000
    var b = (sc / 100) % 100
    var frac = clampf((a - 2) / 13.0 + (b - 2) / 169.0, 0.0, 1.0)
    return CUM[cat] + SPAN[cat] * frac
