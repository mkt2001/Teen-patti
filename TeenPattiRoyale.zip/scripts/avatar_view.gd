extends Control

const BG = [Color("e53935"), Color("fb8c00"), Color("d81b60"), Color("1e88e5"), Color("43a047"), Color("8e24aa"), Color("00acc1"), Color("5d4037"), Color("f9a825"), Color("3949ab"), Color("6d4c41"), Color("00897b")]
const SKIN = [Color("f1c27d"), Color("e0ac69"), Color("c68642"), Color("8d5524"), Color("ffdbac")]
const HAIR = [Color("1b1b1b"), Color("4a2c12"), Color("8b5a2b"), Color("0d0d0d"), Color("6d1b1b")]
const FRAMES = [Color(1, 1, 1, 0.5), Color("cd7f32"), Color("c0c0c0"), Color("f6c945"), Color("4dd0e1"), Color("b266ff")]

var idx = 0
var frame = 0

func _draw():
    var c = size / 2.0
    var r = minf(size.x, size.y) / 2.0 - 6.0
    draw_circle(c, r, BG[idx % BG.size()])
    # shoulders (circular segment)
    var pts = PackedVector2Array()
    for k in range(0, 11):
        var a = deg_to_rad(20.0 + k * 14.0)
        pts.append(c + Vector2(cos(a), sin(a)) * r)
    draw_colored_polygon(pts, BG[idx % BG.size()].darkened(0.35))
    var hc = c + Vector2(0, -r * 0.12)
    draw_circle(hc, r * 0.34, SKIN[idx % SKIN.size()])
    var hp = PackedVector2Array()
    for k in range(0, 13):
        var a2 = deg_to_rad(180.0 + k * 15.0)
        hp.append(hc + Vector2(cos(a2), sin(a2)) * r * 0.37)
    draw_colored_polygon(hp, HAIR[(idx + 1) % HAIR.size()])
    draw_circle(hc + Vector2(-r * 0.12, r * 0.02), r * 0.04, Color("222222"))
    draw_circle(hc + Vector2(r * 0.12, r * 0.02), r * 0.04, Color("222222"))
    draw_arc(hc + Vector2(0, r * 0.08), r * 0.14, deg_to_rad(30), deg_to_rad(150), 8, Color("7a2a2a"), 2.0)
    if idx % 4 == 1:
        draw_arc(hc + Vector2(-r * 0.12, r * 0.02), r * 0.09, 0, TAU, 12, Color("111111"), 2.0)
        draw_arc(hc + Vector2(r * 0.12, r * 0.02), r * 0.09, 0, TAU, 12, Color("111111"), 2.0)
    if idx >= 8:
        var g = Color("f6c945")
        var cb = hc + Vector2(0, -r * 0.36)
        draw_colored_polygon(PackedVector2Array([cb + Vector2(-r * 0.2, 0), cb + Vector2(-r * 0.2, -r * 0.18), cb + Vector2(-r * 0.1, -r * 0.08), cb + Vector2(0, -r * 0.22), cb + Vector2(r * 0.1, -r * 0.08), cb + Vector2(r * 0.2, -r * 0.18), cb + Vector2(r * 0.2, 0)]), g)
    if frame == 6:
        var rc = [Color("e53935"), Color("fb8c00"), Color("fdd835"), Color("43a047"), Color("1e88e5"), Color("8e24aa")]
        for k in range(6):
            draw_arc(c, r + 3, deg_to_rad(k * 60.0), deg_to_rad(k * 60.0 + 61.0), 12, rc[k], 6.0)
    else:
        draw_arc(c, r + 3, 0, TAU, 48, FRAMES[frame % FRAMES.size()], 6.0 if frame > 0 else 3.0)
