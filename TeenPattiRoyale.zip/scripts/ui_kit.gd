extends RefCounted

const GOLD = Color("f6c945")

static func dark():
    return GameData.d["settings"]["dark"]

static func panel_col():
    if dark():
        return Color(0.11, 0.06, 0.25, 0.86)
    return Color(0.36, 0.22, 0.66, 0.9)

static func sb(col, radius = 16, border_col = null, border_w = 0, shadow = 0):
    var s = StyleBoxFlat.new()
    s.bg_color = col
    s.set_corner_radius_all(radius)
    if border_col != null and border_w > 0:
        s.border_color = border_col
        s.set_border_width_all(border_w)
    if shadow > 0:
        s.shadow_size = shadow
        s.shadow_color = Color(0, 0, 0, 0.45)
        s.shadow_offset = Vector2(0, 3)
    s.set_content_margin_all(8)
    return s

static func button(text, color = Color("6a2bd9"), font_size = 28, min_size = Vector2(0, 70)):
    var b = Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.4))
    b.add_theme_stylebox_override("normal", sb(color, 18, Color(1, 1, 1, 0.35), 2, 6))
    b.add_theme_stylebox_override("hover", sb(color.lightened(0.15), 18, Color(1, 1, 1, 0.5), 2, 6))
    b.add_theme_stylebox_override("pressed", sb(color.darkened(0.25), 18, Color(1, 1, 1, 0.5), 2, 2))
    b.add_theme_stylebox_override("disabled", sb(color.darkened(0.55), 18, Color(1, 1, 1, 0.1), 2, 0))
    b.pressed.connect(Sfx.play.bind("click"))
    return b

static func label(text, size = 26, color = Color.WHITE, align = HORIZONTAL_ALIGNMENT_CENTER):
    var l = Label.new()
    l.text = str(text)
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
    l.add_theme_constant_override("outline_size", 3)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    return l

static func card(parent, margin = 18, col = null):
    var pc = PanelContainer.new()
    pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var c = panel_col()
    if col != null:
        c = col
    var st = sb(c, 22, Color(1, 1, 1, 0.22), 2, 8)
    st.set_content_margin_all(margin)
    pc.add_theme_stylebox_override("panel", st)
    parent.add_child(pc)
    var vb = VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    pc.add_child(vb)
    return vb

static func fmt(n):
    var v = int(n)
    var neg = v < 0
    var s = str(absi(v))
    var out = ""
    if s.length() <= 3:
        out = s
    else:
        var last3 = s.substr(s.length() - 3)
        var rest = s.substr(0, s.length() - 3)
        var parts = PackedStringArray()
        while rest.length() > 2:
            parts.insert(0, rest.substr(rest.length() - 2))
            rest = rest.substr(0, rest.length() - 2)
        if rest.length() > 0:
            parts.insert(0, rest)
        out = ",".join(parts) + "," + last3
    if neg:
        return "-" + out
    return out

static func _trim(f):
    var s = "%.2f" % f
    if s.contains("."):
        s = s.rstrip("0").rstrip(".")
    return s

static func short(n):
    var v = int(n)
    var a = absi(v)
    var sg = "-" if v < 0 else ""
    if a >= 10000000:
        return sg + _trim(a / 10000000.0) + " Cr"
    if a >= 100000:
        return sg + _trim(a / 100000.0) + " L"
    if a >= 1000:
        return sg + _trim(a / 1000.0) + "K"
    return sg + str(a)
