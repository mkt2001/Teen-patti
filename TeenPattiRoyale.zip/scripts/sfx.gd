extends Node

var sounds = {}
var pool = []
var music_player = null
var music_built = false
var _next = 0

func _ready():
    for i in range(8):
        var p = AudioStreamPlayer.new()
        p.volume_db = -3.0
        add_child(p)
        pool.append(p)
    music_player = AudioStreamPlayer.new()
    music_player.volume_db = -15.0
    add_child(music_player)
    _build_sounds()
    call_deferred("_late_music")

func _late_music():
    await get_tree().create_timer(0.8).timeout
    apply_settings()

func apply_settings():
    var on = GameData.d["settings"]["music"]
    if on:
        if not music_built:
            music_player.stream = _build_music()
            music_built = true
        if not music_player.playing:
            music_player.play()
    else:
        music_player.stop()

func play(snd):
    if not GameData.d["settings"]["sound"]:
        return
    if not sounds.has(snd):
        return
    var p = null
    for q in pool:
        if not q.playing:
            p = q
            break
    if p == null:
        p = pool[_next % pool.size()]
        _next += 1
    p.stream = sounds[snd]
    p.play()

func vibrate(ms):
    if GameData.d["settings"]["vib"]:
        Input.vibrate_handheld(ms)

func _wav(samples, rate = 22050, loop = false):
    var bytes = PackedByteArray()
    bytes.resize(samples.size() * 2)
    for i in range(samples.size()):
        var v = clampf(samples[i], -1.0, 1.0)
        bytes.encode_s16(i * 2, int(v * 30000.0))
    var s = AudioStreamWAV.new()
    s.format = AudioStreamWAV.FORMAT_16_BITS
    s.mix_rate = rate
    s.stereo = false
    s.data = bytes
    if loop:
        s.loop_mode = AudioStreamWAV.LOOP_FORWARD
        s.loop_begin = 0
        s.loop_end = samples.size()
    return s

func _tone(freq, dur, vol = 0.5, kind = 1, decay = 5.0, rate = 22050):
    var n = int(dur * rate)
    var out = PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        var t = float(i) / rate
        var env = exp(-decay * float(i) / n) * minf(1.0, float(i) / 40.0)
        var v = sin(TAU * freq * t)
        if kind == 1:
            v = 0.6 * (v + 0.4 * sin(TAU * freq * 2.0 * t) + 0.2 * sin(TAU * freq * 3.0 * t))
        out[i] = v * env * vol
    return out

func _noise(dur, vol, decay):
    var n = int(dur * 22050)
    var out = PackedFloat32Array()
    out.resize(n)
    var prev = 0.0
    for i in range(n):
        var r = randf() * 2.0 - 1.0
        prev = 0.55 * prev + 0.45 * r
        out[i] = prev * exp(-decay * float(i) / n) * vol
    return out

func _cat(list):
    var out = PackedFloat32Array()
    for a in list:
        out.append_array(a)
    return out

func _mix(list):
    var n = 0
    for a in list:
        n = maxi(n, a.size())
    var out = PackedFloat32Array()
    out.resize(n)
    for a in list:
        for i in range(a.size()):
            out[i] += a[i]
    return out

func _arp(freqs, dur, vol):
    var parts = []
    for f in freqs:
        parts.append(_tone(f, dur, vol, 1, 3.0))
    return _cat(parts)

func _build_sounds():
    sounds["click"] = _wav(_tone(1100, 0.06, 0.45, 1, 7.0))
    sounds["deal"] = _wav(_noise(0.09, 0.6, 7.0))
    sounds["chip"] = _wav(_cat([_tone(2600, 0.05, 0.4, 1, 8.0), _tone(3300, 0.07, 0.35, 1, 8.0)]))
    sounds["flip"] = _wav(_noise(0.14, 0.5, 4.0))
    sounds["turn"] = _wav(_tone(880, 0.15, 0.3, 0, 4.0))
    sounds["pack"] = _wav(_tone(300, 0.2, 0.4, 1, 5.0))
    sounds["coin"] = _wav(_arp([1318.0, 1760.0], 0.08, 0.35))
    sounds["tick"] = _wav(_tone(900, 0.03, 0.3, 0, 6.0))
    sounds["lose"] = _wav(_arp([392.0, 311.0, 247.0], 0.22, 0.4))
    sounds["levelup"] = _wav(_arp([523.25, 659.25, 783.99, 1046.5], 0.1, 0.4))
    var fin = _mix([_tone(1046.5, 0.6, 0.3, 1, 3.0), _tone(1318.5, 0.6, 0.25, 1, 3.0), _tone(1568.0, 0.6, 0.2, 1, 3.0)])
    sounds["win"] = _wav(_cat([_arp([523.25, 659.25, 783.99, 1046.5], 0.12, 0.4), fin]))

func _build_music():
    var rate = 8000
    var total = rate * 12
    var buf = PackedFloat32Array()
    buf.resize(total)
    var chords = [[130.81, 164.81, 196.0], [110.0, 130.81, 164.81], [87.31, 110.0, 130.81], [98.0, 123.47, 146.83]]
    var seg = rate * 3
    for ci in range(4):
        var ch = chords[ci]
        var start = ci * seg
        for i in range(seg):
            var t = float(i) / rate
            var env = minf(1.0, t / 0.4) * minf(1.0, (3.0 - t) / 0.5)
            var v = 0.0
            for f in ch:
                v += sin(TAU * f * (start + i) / rate) * 0.07
            buf[start + i] += v * env
        var pat = [0, 1, 2, 1, 2, 1]
        for k in range(6):
            var f2 = ch[pat[k]] * 2.0
            var s0 = start + int(k * 0.5 * rate)
            var nlen = int(0.5 * rate)
            for i in range(nlen):
                if s0 + i >= total:
                    break
                var tt = float(i) / rate
                buf[s0 + i] += sin(TAU * f2 * tt) * exp(-5.0 * tt) * 0.12
    return _wav(buf, rate, true)
