extends Control

var col = Color("d62839")
var count = 1

func _draw():
    var r = minf(size.x, size.y) * 0.5
    var c = size / 2.0
    for i in range(count):
        var cc = c + Vector2(0, -i * 6.0)
        draw_circle(cc + Vector2(0, 3), r * 0.95, Color(0, 0, 0, 0.35))
        draw_circle(cc, r * 0.95, col)
        draw_arc(cc, r * 0.75, 0.0, TAU, 24, Color(1, 1, 1, 0.9), 3.0)
        draw_circle(cc, r * 0.5, col.darkened(0.2))
