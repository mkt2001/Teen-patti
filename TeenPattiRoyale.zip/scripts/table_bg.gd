extends Control

const THEMES = [
    {"n": "Emerald Felt", "c1": Color("0f7a4a"), "c2": Color("064d2e"), "rim": Color("5a3416")},
    {"n": "Royal Red", "c1": Color("a3182b"), "c2": Color("5e0b19"), "rim": Color("3b2412")},
    {"n": "Sapphire Blue", "c1": Color("1a4fa3"), "c2": Color("0b2a63"), "rim": Color("2b2b3d")},
    {"n": "Purple Night", "c1": Color("6a2bb8"), "c2": Color("361060"), "rim": Color("1f1230")},
    {"n": "Black and Gold", "c1": Color("2a2a2a"), "c2": Color("0e0e0e"), "rim": Color("b8860b")},
    {"n": "Ocean Teal", "c1": Color("0f8a8a"), "c2": Color("075252"), "rim": Color("3a2a18")}
]

var theme_idx = 0
var menu_mode = false

func _ready():
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    resized.connect(queue_redraw)

func _ellipse(c, rx, ry, col):
    var pts = PackedVector2Array()
    for i in range(64):
        var a = TAU * i / 64.0
        pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
    draw_colored_polygon(pts, col)

func _draw():
    var sz = size
    var dark = GameData.d["settings"]["dark"]
    var top = Color("1b1038") if dark else Color("8a6bd1")
    var bot = Color("3a1466") if dark else Color("c9b3f5")
    if not menu_mode:
        top = Color("12082a")
        bot = Color("2a0f4f")
    draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(sz.x, 0), Vector2(sz.x, sz.y), Vector2(0, sz.y)]), PackedColorArray([top, top, bot, bot]))
    if menu_mode:
        var cols = [Color(0.96, 0.78, 0.27, 0.10), Color(0.6, 0.3, 1.0, 0.12), Color(0.2, 0.7, 1.0, 0.09)]
        for i in range(14):
            var p = Vector2(fposmod(i * 311.0, sz.x), fposmod(i * 197.0, sz.y))
            draw_circle(p, 40.0 + (i % 5) * 28.0, cols[i % 3])
        return
    var th = THEMES[theme_idx % THEMES.size()]
    var c = Vector2(sz.x * 0.5, sz.y * 0.47)
    var rx = sz.x * 0.44
    var ry = sz.y * 0.37
    _ellipse(c + Vector2(0, 10), rx + 26, ry + 26, Color(0, 0, 0, 0.35))
    _ellipse(c, rx + 22, ry + 22, th["rim"])
    _ellipse(c, rx + 8, ry + 8, Color("f6c945"))
    _ellipse(c, rx + 4, ry + 4, th["rim"])
    _ellipse(c, rx, ry, th["c2"])
    _ellipse(c, rx * 0.95, ry * 0.93, th["c1"])
    _ellipse(c, rx * 0.62, ry * 0.56, th["c1"].lightened(0.07))
    var font = ThemeDB.fallback_font
    draw_string(font, Vector2(c.x - 300, c.y + ry * 0.62), "TEEN PATTI ROYALE", HORIZONTAL_ALIGNMENT_CENTER, 600, 44, Color(1, 1, 1, 0.12))
